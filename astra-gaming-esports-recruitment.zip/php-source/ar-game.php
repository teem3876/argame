<?php
/**
 * ar-game.php - หน้าหลักของระบบทดสอบปฏิกิริยานักกีฬาอีสปอร์ต AR Game
 */

// เริ่มต้นใช้งาน Session
session_start();

// นำเข้าฐานข้อมูลเพื่อดึงข้อมูลสถิติสดใหม่ล่าสุด
require_once 'db.php';

// ตรวจสอบความปลอดภัย: หากยังไม่ได้เข้าสู่ระบบ ให้เตะกลับไปหน้าแรกทันที
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$athlete_id = $_SESSION['athlete_id'];
$fullname = $_SESSION['fullname'];
$ign = $_SESSION['ign'];
$game = $_SESSION['game'];

// ดึงคะแนนสูงสุดล่าสุดของผู้เล่นคนนี้จากฐานข้อมูล MySQL
try {
    $stmt = $pdo->prepare("SELECT high_score FROM users WHERE id = :id");
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch();
    $high_score = $user ? intval($user['high_score']) : 0;
} catch (PDOException $e) {
    $high_score = 0; // ในกรณีที่เกิดข้อผิดพลาดให้ใช้ 0 ไปก่อน
}
?>
<!DOCTYPE html>
<html lang="th" class="h-full bg-slate-950">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AR Reaction Test - Astra Gaming</title>
    <!-- โหลด Tailwind CSS ผ่าน CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Anuphan:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- นำเข้าไลบรารี MediaPipe Hands และ Camera Utils ผ่าน CDN เพื่อช่วยจับภาพและค้นหาตำแหน่งมือ -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>

    <style>
        body {
            font-family: 'Anuphan', sans-serif;
        }
        /* เสริมคลาสหมุนกล้องเป็นกระจกเงาเพื่อการสัมผัสที่แม่นยำ */
        .mirror-canvas {
            transform: scaleX(-1);
        }
    </style>
</head>
<body class="h-full text-slate-100 flex flex-col justify-between">

    <!-- Header / แผงข้อมูลผู้ใช้ -->
    <header class="border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-bold text-xl text-white">
                    A
                </div>
                <div>
                    <h1 class="font-bold text-base leading-none text-white tracking-wider">ASTRA REACTION TESTER</h1>
                    <p class="text-[10px] text-cyan-400 font-medium tracking-widest mt-1">ATHLETE IDENTIFICATION: <?php echo htmlspecialchars($athlete_id); ?></p>
                </div>
            </div>
            
            <div class="flex items-center gap-4">
                <div class="text-right hidden md:block">
                    <p class="text-xs text-slate-400">เข้าสู่ระบบโดย</p>
                    <p class="text-sm font-bold text-white"><?php echo htmlspecialchars($fullname); ?> <span class="text-cyan-400 font-mono">(<?php echo htmlspecialchars($ign); ?>)</span></p>
                </div>
                <div class="bg-indigo-500/10 border border-indigo-500/20 px-3 py-1.5 rounded-lg text-xs font-semibold text-indigo-400">
                    เกมถนัด: <?php echo htmlspecialchars($game); ?>
                </div>
                <a href="logout.php" class="bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 px-4 py-1.5 rounded-lg text-xs font-bold transition-all">
                    ออกจากระบบ
                </a>
            </div>
        </div>
    </header>

    <!-- Main Section -->
    <main class="max-w-7xl mx-auto px-6 py-8 flex-1 w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        <!-- ฝั่งซ้าย: แดชบอร์ดและแผงสถิติ -->
        <section class="lg:col-span-4 flex flex-col gap-6">
            
            <!-- การ์ดคะแนน (Stats Card) -->
            <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
                <h3 class="text-xs text-slate-400 font-semibold tracking-widest uppercase mb-4">ข้อมูลคะแนนและสถิติ</h3>
                
                <div class="grid grid-cols-2 gap-4">
                    <!-- คะแนนรอบปัจจุบัน -->
                    <div class="bg-slate-950 border border-slate-800 p-4 rounded-xl text-center">
                        <p class="text-[10px] text-slate-500 uppercase tracking-wider">คะแนนรอบปัจจุบัน</p>
                        <p id="current-score" class="text-4xl font-black text-cyan-400 font-mono mt-1">0</p>
                    </div>

                    <!-- คะแนนสูงสุดตลอดกาล -->
                    <div class="bg-slate-950 border border-slate-800 p-4 rounded-xl text-center relative overflow-hidden">
                        <div class="absolute -top-6 -right-6 w-12 h-12 bg-amber-500/10 rounded-full blur"></div>
                        <p class="text-[10px] text-slate-500 uppercase tracking-wider">คะแนนสูงสุดเดิม (High Score)</p>
                        <p id="high-score" class="text-4xl font-black text-amber-400 font-mono mt-1"><?php echo $high_score; ?></p>
                    </div>
                </div>

                <!-- เวลาที่เหลือ -->
                <div class="mt-6">
                    <div class="flex justify-between text-xs font-bold text-slate-400 mb-1.5 uppercase">
                        <span>เวลาถอยหลัง</span>
                        <span id="timer-text" class="text-rose-400 font-mono">30 วินาที</span>
                    </div>
                    <div class="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                        <div id="timer-progress" class="bg-rose-500 h-full w-full transition-all duration-100"></div>
                    </div>
                </div>
            </div>

            <!-- กติกากล้องและวิธีเล่น -->
            <div class="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex-1 flex flex-col justify-between">
                <div>
                    <h3 class="text-xs text-slate-400 font-semibold tracking-widest uppercase mb-3.5">วิธีการผ่านการทดสอบ</h3>
                    <ul class="space-y-3.5 text-xs text-slate-300">
                        <li class="flex items-start gap-2.5">
                            <span class="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono font-bold flex items-center justify-center flex-shrink-0">1</span>
                            <span>อนุญาตให้ใช้งาน<b>กล้องเว็บแคม</b>เพื่อให้ระบบทำการวิเคราะห์มือของคุณ</span>
                        </li>
                        <li class="flex items-start gap-2.5">
                            <span class="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono font-bold flex items-center justify-center flex-shrink-0">2</span>
                            <span>ยกมือขึ้นหน้ากล้อง <b>ใช้นิ้วชี้หรือจุดกึ่งกลางฝ่ามือ</b> เลื่อนไปสัมผัสไอคอนดาวดวงสีทองที่สุ่มปรากฏขึ้นบนจอภาพ</span>
                        </li>
                        <li class="flex items-start gap-2.5">
                            <span class="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono font-bold flex items-center justify-center flex-shrink-0">3</span>
                            <span>ทำแต้มให้มากที่สุดภายในเวลา <b>30 วินาที</b> คะแนนจะถูกส่งไปเก็บยังระบบจัดอันดับทันทีที่ทำลายสถิติเก่าได้สำเร็จ</span>
                        </li>
                    </ul>
                </div>

                <!-- แผงสลับโหมดกรณีไม่มีกล้อง -->
                <div class="mt-6 pt-5 border-t border-slate-800/80">
                    <p class="text-[11px] text-slate-500 text-center mb-3">หากไม่มีเว็บแคมหรือกล้องไม่ทำงาน สามารถกดจำลองโหมดสัมผัสด้วยเมาส์ได้</p>
                    <button id="toggle-fallback" 
                            class="w-full bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 font-semibold text-xs py-2.5 rounded-lg transition-all flex items-center justify-center gap-2">
                        🎮 สลับเป็นโหมดเล่นด้วยเมาส์
                    </button>
                </div>
            </div>
        </section>

        <!-- ฝั่งขวา: สนามทดสอบ (AR Game Screen) -->
        <section class="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col overflow-hidden relative min-h-[400px]">
            
            <!-- ปุ่มควบคุมการเริ่มเล่น -->
            <div class="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/20">
                <span id="game-status" class="text-xs text-amber-400 font-semibold flex items-center gap-2">
                    ● รอการเริ่มต้นทดสอบ...
                </span>
                <button id="start-btn" 
                        class="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs py-2 px-5 rounded-lg transition-all shadow-md shadow-emerald-500/10">
                    🚀 เริ่มทำการทดสอบ (START)
                </button>
            </div>

            <!-- กล้องเว็บแคม (ซ่อนไว้สำหรับแอบตรวจจับ) -->
            <video id="webcam-video" style="display:none;" autoplay playsinline></video>

            <!-- พื้นที่แสดงเกม (Canvas Arena) -->
            <div class="flex-1 w-full bg-slate-950 relative flex items-center justify-center overflow-hidden">
                <canvas id="game-canvas" width="640" height="480" class="mirror-canvas max-w-full h-auto rounded-lg shadow-inner"></canvas>

                <!-- จอบังกรณีโมเดลกำลังดาวน์โหลด -->
                <div id="loader" class="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center gap-4 text-center p-6 transition-opacity duration-300">
                    <div class="w-10 h-10 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
                    <div>
                        <p class="text-sm font-bold text-white">กำลังโหลดไลบรารีวิเคราะห์ท่าทางมือ (AR Engine)...</p>
                        <p class="text-xs text-slate-500 mt-1">กรุณารอสักครู่ (หรือเลือกสลับโหมดเล่นด้วยเมาส์ด้านซ้ายได้เลย)</p>
                    </div>
                </div>

                <!-- บอร์ดสรุปคะแนนหลังหมดเวลา -->
                <div id="gameover-modal" class="absolute inset-0 bg-slate-950/95 flex flex-col items-center justify-center p-6 text-center hidden">
                    <div class="max-w-md bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-2xl relative">
                        <div class="w-16 h-16 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center text-3xl mx-auto mb-4 animate-bounce">
                            ⏱
                        </div>
                        <h4 class="text-2xl font-black text-white">หมดเวลาทดสอบ!</h4>
                        <p class="text-xs text-slate-400 mt-1">สรุปการทดสอบปฏิกิริยาและประสาทการรับรู้</p>

                        <div class="my-6 bg-slate-950/60 p-5 rounded-xl border border-slate-800/80">
                            <p class="text-sm text-slate-400">คะแนนที่คุณทำได้</p>
                            <p id="final-score" class="text-5xl font-mono font-black text-cyan-400 mt-1">0</p>
                            <p id="record-status" class="text-xs font-bold text-emerald-400 mt-3 hidden">🎉 ยอดเยี่ยม! คุณทำลายสถิติคะแนนสูงสุดเดิมสำเร็จ</p>
                        </div>

                        <div class="flex gap-4">
                            <button onclick="restartTest()" 
                                    class="flex-1 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-xs py-3 rounded-lg transition-all">
                                ทำการทดสอบอีกรอบ
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </section>

    </main>

    <!-- Footer -->
    <footer class="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-600">
        <div class="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p>© 2026 Astra Gaming Esports Club. All Rights Reserved.</p>
            <p>ระบบตรวจจับการเคลื่อนไหวผ่าน Webcamera (MediaPipe AR Hands)</p>
        </div>
    </footer>

    <!-- ส่วนสคริปต์ควบคุมการทำงานของเกม AR -->
    <script>
        // ประกาศตัวแปรอ้างอิง DOM Elements
        const videoElement = document.getElementById('webcam-video');
        const canvasElement = document.getElementById('game-canvas');
        const canvasCtx = canvasElement.getContext('2d');
        const loader = document.getElementById('loader');
        const startBtn = document.getElementById('start-btn');
        const toggleFallbackBtn = document.getElementById('toggle-fallback');
        const currentScoreText = document.getElementById('current-score');
        const highScoreText = document.getElementById('high-score');
        const timerText = document.getElementById('timer-text');
        const timerProgressBar = document.getElementById('timer-progress');
        const gameStatus = document.getElementById('game-status');
        const gameoverModal = document.getElementById('gameover-modal');
        const finalScoreText = document.getElementById('final-score');
        const recordStatusText = document.getElementById('record-status');

        // ข้อมูลสเตตัสเกม
        let localScore = 0;
        let high_score = <?php echo $high_score; ?>;
        let gameTimeLeft = 30; // 30 วินาที
        let gameInterval = null;
        let isPlaying = false;
        let fallbackMode = false; // โหมดเล่นด้วยเมาส์ (หากไม่มีกล้อง)
        let trackingReady = false;

        // ข้อมูลไอเทมดาวทอง (Star)
        let starX = 150;
        let starY = 150;
        const starRadius = 24;

        // ข้อมูลนิ้วชี้หรือพิกัดเคอร์เซอร์ของผู้เล่น
        let pointerX = -100;
        let pointerY = -100;
        let isHandDetected = false;

        // ตัวกำเนิดเสียงเอฟเฟกต์ด้วย Web Audio API (ไม่ต้องโหลดไฟล์เสียงภายนอก)
        function playBeep(frequency, duration) {
            try {
                const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioCtx.createOscillator();
                const gainNode = audioCtx.createGain();
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(frequency, audioCtx.currentTime);
                gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
                oscillator.connect(gainNode);
                gainNode.connect(audioCtx.destination);
                oscillator.start();
                oscillator.stop(audioCtx.currentTime + duration);
            } catch (e) {
                console.log("เสียงเอฟเฟกต์ติดขัด");
            }
        }

        // ฟังก์ชันสุ่มพิกัดดาวใหม่บนจอ canvas
        function spawnStar() {
            // สุ่มพิกัดให้อยู่ห่างจากขอบจอเล็กน้อย
            const margin = 50;
            starX = Math.floor(Math.random() * (canvasElement.width - margin * 2)) + margin;
            starY = Math.floor(Math.random() * (canvasElement.height - margin * 2)) + margin;
        }

        // ฟังก์ชันการวาดภาพลงบนผืนผ้าใบ (Canvas Rendering Loop)
        function render() {
            canvasCtx.save();
            canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

            if (!fallbackMode && videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) {
                // วาดภาพวิดีโอจากกล้องลงบนแคนวาสแบบกระจกเงา
                canvasCtx.drawImage(videoElement, 0, 0, canvasElement.width, canvasElement.height);
            } else {
                // หากเป็นโหมดเมาส์ ให้วาดพื้นหลังสีมืดสไตล์อวกาศไซเบอร์
                canvasCtx.fillStyle = "#090d16";
                canvasCtx.fillRect(0, 0, canvasElement.width, canvasElement.height);
                
                // วาดลายตารางข่ายงานเน็ตเวิร์ก (Cyber Grid)
                canvasCtx.strokeStyle = "#121a2c";
                canvasCtx.lineWidth = 1;
                for (let i = 0; i < canvasElement.width; i += 40) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(i, 0);
                    canvasCtx.lineTo(i, canvasElement.height);
                    canvasCtx.stroke();
                }
                for (let j = 0; j < canvasElement.height; j += 40) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(0, j);
                    canvasCtx.lineTo(canvasElement.width, j);
                    canvasCtx.stroke();
                }
            }

            // ถ้าอยู่ในเกม ให้วาดไอคอน "ดาวทองคำ"
            if (isPlaying) {
                // วาดประกายรัศมีวงรอบนอก
                const pulse = Math.abs(Math.sin(Date.now() * 0.005)) * 10;
                const gradient = canvasCtx.createRadialGradient(starX, starY, 2, starX, starY, starRadius + pulse);
                gradient.addColorStop(0, 'rgba(251, 191, 36, 0.9)');
                gradient.addColorStop(0.3, 'rgba(251, 191, 36, 0.4)');
                gradient.addColorStop(1, 'rgba(251, 191, 36, 0)');
                
                canvasCtx.beginPath();
                canvasCtx.fillStyle = gradient;
                canvasCtx.arc(starX, starY, starRadius + pulse, 0, 2 * Math.PI);
                canvasCtx.fill();

                // วาดแกนกลางดาวห้าแฉก
                drawStarShape(canvasCtx, starX, starY, 5, starRadius - 6, starRadius / 2 - 3);
            }

            // วาดเป้าหรือสัญลักษณ์ชี้เป้าของผู้เล่น (Pointer Indicator)
            if (isHandDetected || fallbackMode) {
                // วาดรัศมีวงแหวนสแกนรอบพอยเตอร์
                canvasCtx.beginPath();
                canvasCtx.strokeStyle = '#22d3ee';
                canvasCtx.lineWidth = 2;
                canvasCtx.arc(pointerX, pointerY, 15, 0, 2 * Math.PI);
                canvasCtx.stroke();

                // วาดจุดสีน้ำเงินแกนกลางประสาทประสานงาน
                canvasCtx.beginPath();
                canvasCtx.fillStyle = '#06b6d4';
                canvasCtx.arc(pointerX, pointerY, 5, 0, 2 * Math.PI);
                canvasCtx.fill();
            }

            canvasCtx.restore();

            // รันการวาดอย่างต่อเนื่อง
            requestAnimationFrame(render);
        }

        // ฟังก์ชันวาดรูปทรงดาวห้าแฉก
        function drawStarShape(ctx, cx, cy, spikes, outerRadius, innerRadius) {
            let rot = Math.PI / 2 * 3;
            let x = cx;
            let y = cy;
            let step = Math.PI / spikes;

            ctx.beginPath();
            ctx.moveTo(cx, cy - outerRadius)
            for (let i = 0; i < spikes; i++) {
                x = cx + Math.cos(rot) * outerRadius;
                y = cy + Math.sin(rot) * outerRadius;
                ctx.lineTo(x, y)
                rot += step

                x = cx + Math.cos(rot) * innerRadius;
                y = cy + Math.sin(rot) * innerRadius;
                ctx.lineTo(x, y)
                rot += step
            }
            ctx.lineTo(cx, cy - outerRadius);
            ctx.closePath();
            ctx.fillStyle = '#fbbf24';
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 1.5;
            ctx.stroke();
        }

        // ตรวจสอบการชนโดนดาวระหว่างพอยเตอร์กับพิกัดดาว
        function checkCollision() {
            if (!isPlaying) return;
            
            const distance = Math.hypot(pointerX - starX, pointerY - starY);
            // หากพิกัดห่างกันน้อยกว่ารัศมีพอยเตอร์บวกดาว ยินดีด้วยคุณได้คะแนน!
            if (distance < starRadius + 15) {
                localScore += 1;
                currentScoreText.innerText = localScore;
                
                // เล่นเสียงบี๊บความถี่สูงแสดงการสำเร็จแต้ม
                playBeep(650, 0.12);
                
                // สุ่มตำแหน่งดาวใหม่
                spawnStar();
            }
        }

        // เริ่มตั้งเวลาถอยหลัง 30 วินาที
        function startTimer() {
            gameTimeLeft = 30;
            timerText.innerText = gameTimeLeft + " วินาที";
            timerProgressBar.style.width = "100%";
            timerProgressBar.style.backgroundColor = "#ef4444";

            gameInterval = setInterval(() => {
                gameTimeLeft--;
                timerText.innerText = gameTimeLeft + " วินาที";
                
                // อัปเดตแถบความคืบหน้าของเวลา
                const percentage = (gameTimeLeft / 30) * 100;
                timerProgressBar.style.width = percentage + "%";

                if (gameTimeLeft <= 0) {
                    endGame();
                }
            }, 1000);
        }

        // สิ้นสุดเกมการทดสอบ
        function endGame() {
            isPlaying = false;
            clearInterval(gameInterval);
            gameStatus.innerHTML = "● จบการทดสอบการปฏิกิริยา";
            gameStatus.className = "text-xs text-rose-500 font-semibold";
            
            // โชว์ผลรวมคะแนนลงหน้าต่างบอร์ดสรุป
            finalScoreText.innerText = localScore;
            gameoverModal.classList.remove('hidden');

            // นำเสนอเอฟเฟกต์สรุปผลลัพธ์
            playBeep(220, 0.2);
            setTimeout(() => playBeep(290, 0.3), 200);

            // ตรวจสอบสถิติสูงสุดใหม่ หากทำแต้มเหนือกว่าสถิติเก่าใน MySQL
            if (localScore > high_score) {
                recordStatusText.classList.remove('hidden');
                
                // ส่งสถิติคลิปคะแนนด้วย Fetch API กลับไปยัง php-source/update-score.php
                fetch('update-score.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ score: localScore })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        // อัปเดตการแสดงผลในหน้าจอหลักทันทีโดยไม่ต้องรีโหลด
                        high_score = localScore;
                        highScoreText.innerText = high_score;
                    }
                })
                .catch(err => {
                    console.error("ผิดพลาดทางระบบเชื่อมข้อมูล: ", err);
                });
            } else {
                recordStatusText.classList.add('hidden');
            }
        }

        // การเริ่มระบบกล้องและโมเดลวิเคราะห์มือ MediaPipe
        let handsModel = null;
        let cameraObj = null;

        function initAR() {
            try {
                // ตั้งค่าโมเดล MediaPipe Hands
                handsModel = new Hands({
                    locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
                });

                handsModel.setOptions({
                    maxNumHands: 1,
                    modelComplexity: 1,
                    minDetectionConfidence: 0.6,
                    minTrackingConfidence: 0.6
                });

                // การทำงานเมื่อตรวจเจอและประมวลผลตำแหน่งมือเสร็จแล้ว
                handsModel.onResults((results) => {
                    if (fallbackMode) return; // ข้ามขั้นตอนนี้หากอยู่บนโหมดเมาส์
                    
                    if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                        isHandDetected = true;
                        
                        // ดึงพิกัดของ Landmark ตัวที่ 8 (ปลายนิ้วชี้: INDEX_FINGER_TIP)
                        const indexFingerTip = results.multiHandLandmarks[0][8];
                        
                        // แปลงพิกัดเทียบขนาดผืนผ้าใบแคนวาส
                        // (เนื่องจากวาดกล้องกลับด้านใน CSS/JS ดังนั้นต้องทำการลบค่าแกน X ออกจากผลรวมกว้างแคนวาส)
                        pointerX = Math.floor(indexFingerTip.x * canvasElement.width);
                        pointerY = Math.floor(indexFingerTip.y * canvasElement.height);

                        // ทำการตรวจจับชนดาว
                        checkCollision();
                    } else {
                        isHandDetected = false;
                    }
                });

                // ทำการเปิดกล้องผ่านเครื่องมือช่วยของ MediaPipe
                cameraObj = new Camera(videoElement, {
                    onFrame: async () => {
                        if (!fallbackMode) {
                            await handsModel.send({ image: videoElement });
                        }
                    },
                    width: 640,
                    height: 480
                });

                cameraObj.start()
                    .then(() => {
                        loader.classList.add('opacity-0');
                        setTimeout(() => loader.classList.add('hidden'), 300);
                        trackingReady = true;
                        gameStatus.innerText = "● กล้องพร้อมใช้งาน และเชื่อมต่อระบบ AI AR แล้ว";
                        gameStatus.className = "text-xs text-emerald-400 font-semibold";
                    })
                    .catch((err) => {
                        console.warn("กล้องเว็บแคมใช้งานไม่ได้ ย้ายไปจำลองโหมดสัมผัสทางเมาส์อัตโนมัติ: ", err);
                        enableFallbackMode();
                    });

            } catch (error) {
                console.error("โหลดโมเดลระบบ AR ผิดพลาด: ", error);
                enableFallbackMode();
            }
        }

        // ย้ายการทำงานกรณีไม่มีกล้องมาใช้เมาส์สัมผัสดาว (Fallback Mouse Simulation)
        function enableFallbackMode() {
            fallbackMode = true;
            loader.classList.add('opacity-0');
            setTimeout(() => loader.classList.add('hidden'), 300);
            
            // ยกเลิกคลาสกลับหน้ากล้อง เพื่อให้พิกัดเมาส์วิ่งตรงตามจริง
            canvasElement.classList.remove('mirror-canvas');
            
            toggleFallbackBtn.innerHTML = "✨ คืนค่าใช้งานระบบกล้อง Webcamera";
            gameStatus.innerText = "● ทำงานบนโหมดทดสอบเมาส์สัมผัสหน้าจอ";
            gameStatus.className = "text-xs text-cyan-400 font-semibold font-bold animate-pulse";
            
            // ดักจับจับความเคลื่อนเมาส์เหนือกราฟฟิกแคนวาส
            canvasElement.addEventListener('mousemove', (e) => {
                if (!fallbackMode) return;
                const rect = canvasElement.getBoundingClientRect();
                // แปลงอัตราสเกลของหน้าจอจริงเทียบพิกัดแกนแคนวาส 640x480
                pointerX = (e.clientX - rect.left) * (canvasElement.width / rect.width);
                pointerY = (e.clientY - rect.top) * (canvasElement.height / rect.height);
                
                checkCollision();
            });
        }

        // ปุ่มกดสลับโหมดไปมาระหว่างกล้องจริงและเมาส์
        toggleFallbackBtn.addEventListener('click', () => {
            if (fallbackMode) {
                // พยายามคืนสู่ระบบวิเคราะห์กล้อง AR
                fallbackMode = false;
                canvasElement.classList.add('mirror-canvas');
                toggleFallbackBtn.innerHTML = "🎮 สลับเป็นโหมดเล่นด้วยเมาส์";
                gameStatus.innerText = "● รอวิเคราะห์กล้องเว็บแคม...";
                gameStatus.className = "text-xs text-amber-400 font-semibold";
                
                if (!trackingReady) {
                    loader.classList.remove('hidden', 'opacity-0');
                    initAR();
                } else {
                    gameStatus.innerText = "● เชื่อมต่อวิเคราะห์กล้องแล้ว";
                    gameStatus.className = "text-xs text-emerald-400 font-semibold";
                }
            } else {
                enableFallbackMode();
            }
        });

        // ควบคุมปุ่มเริ่มต้นทดสอบ (START)
        startBtn.addEventListener('click', () => {
            if (isPlaying) return;
            
            // เตรียมรีเซ็ตความพร้อม
            localScore = 0;
            currentScoreText.innerText = "0";
            isPlaying = true;
            gameoverModal.classList.add('hidden');
            
            gameStatus.innerHTML = "⚡ การทดสอบปฏิกิริยามือประสานตากำลังดำเนินการ!";
            gameStatus.className = "text-xs text-emerald-400 font-bold animate-pulse";
            
            playBeep(440, 0.1);
            setTimeout(() => playBeep(520, 0.1), 120);
            
            // เริ่มสุ่มดาวดวงแรก และตั้งเวลาถอยหลัง
            spawnStar();
            startTimer();
        });

        // รีสตาร์ทรอบการทดสอบจากแผงสรุป
        function restartTest() {
            gameoverModal.classList.add('hidden');
            startBtn.click();
        }

        // โหลดหน้าจอแล้วรันระบบวาดภาพ Render Loop ทันที พร้อมระบบเปิดวิเคราะห์กล้อง
        window.onload = () => {
            render();
            // ลองเปิดระบบตรวจจับภาพวิเคราะห์ประสาทสัมผัส AR Hands
            initAR();
        };
    </script>
</body>
</html>
