<?php
/**
 * db.php - ไฟล์เชื่อมต่อฐานข้อมูล MySQL ด้วย PDO
 * เหมาะสำหรับใช้งานร่วมกับ XAMPP (localhost)
 */

// กำหนดรายละเอียดการเชื่อมต่อฐานข้อมูล
$host = "localhost";
$dbname = "astra_gaming";
$username = "root"; // บัญชีผู้ใช้เริ่มต้นของ XAMPP
$password = "";     // รหัสผ่านเริ่มต้นของ XAMPP เป็นค่าว่าง

try {
    // สร้างการเชื่อมต่อผ่าน PDO พร้อมกำหนด Encoding เป็น UTF-8
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    
    // ตั้งค่า Error Mode ให้แสดง Exception เมื่อเกิดข้อผิดพลาด
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // ตั้งค่า Fetch Mode เริ่มต้นให้ส่งค่ากลับมาเป็นแบบ Associative Array
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    // แสดงข้อความเมื่อเชื่อมต่อล้มเหลว และหยุดการทำงานของสคริปต์
    die("เกิดข้อผิดพลาดในการเชื่อมต่อฐานข้อมูล: " . $e->getMessage());
}
?>
