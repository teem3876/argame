<?php
/**
 * index.php - หน้าแรก Landing Page สังกัด Astra Gaming และระบบเข้าสู่ระบบ
 */

// เริ่มต้นใช้งาน Session
session_start();

// นำเข้าไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db.php';

// หากเข้าสู่ระบบไว้แล้ว ให้ข้ามไปหน้าเกม AR ได้เลย
if (isset($_SESSION['user_id'])) {
    header("Location: ar-game.php");
    exit();
}

$error_message = "";

// ตรวจสอบการกดปุ่มเข้าสู่ระบบ (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (empty($username) || empty($password)) {
        $error_message = "กรุณากรอกข้อมูลบัญชีผู้ใช้และรหัสผ่านให้ครบถ้วน";
    } else {
        try {
            // เตรียมคำสั่ง SQL เพื่อค้นหาชื่อผู้ใช้งาน
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch();

            // หากพบผู้ใช้ในระบบ และตรวจสอบรหัสผ่านถูกต้อง
            if ($user && password_verify($password, $user['password'])) {
                // บันทึกค่าที่จำเป็นลง Session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['athlete_id'] = $user['athlete_id'];
                $_SESSION['fullname'] = $user['fullname'];
                $_SESSION['ign'] = $user['ign'];
                $_SESSION['game'] = $user['game'];

                // ส่งตัวไปยังหน้าทดสอบปฏิกิริยา (AR Game)
                header("Location: ar-game.php");
                exit();
            } else {
                $error_message = "บัญชีผู้ใช้หรือรหัสผ่านไม่ถูกต้อง กรุณาลองใหม่อีกครั้ง";
            }
        } catch (PDOException $e) {
            $error_message = "เกิดข้อผิดพลาดในการเชื่อมต่อระบบ: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th" class="h-full bg-slate-950">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Astra Gaming - Esports Recruitment</title>
    <!-- โหลด Tailwind CSS ผ่าน CDN เพื่อความสะดวกในการทดสอบบน XAMPP -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Anuphan:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Anuphan', sans-serif;
        }
    </style>
</head>
<body class="h-full text-slate-100 flex flex-col justify-between">

    <!-- Header / Navigation Bar -->
    <header class="border-b border-slate-800 bg-slate-900/50 backdrop-blur">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-bold text-xl text-white shadow-lg shadow-indigo-500/20">
                    A
                </div>
                <div>
                    <h1 class="font-bold text-lg leading-none text-white tracking-wider">ASTRA GAMING</h1>
                    <p class="text-[10px] text-cyan-400 font-medium tracking-widest mt-0.5">THE NEXT LEAGUE GENERATION</p>
                </div>
            </div>
            <div class="hidden md:flex items-center gap-6 text-sm text-slate-300">
                <a href="#" class="hover:text-cyan-400 transition-colors">เกี่ยวกับเรา</a>
                <a href="#" class="hover:text-cyan-400 transition-colors">ทีมในสังกัด</a>
                <a href="#" class="hover:text-cyan-400 transition-colors">ทัวร์นาเมนต์</a>
                <a href="register.php" class="bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 px-4 py-1.5 rounded-md text-xs font-semibold transition-all">สมัครใหม่</a>
            </div>
        </div>
    </header>

    <!-- Main Content Grid -->
    <main class="max-w-7xl mx-auto px-6 py-12 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        <!-- ฝั่งซ้าย: ข้อมูลทีม และเนื้อหาปลุกระดม -->
        <section class="lg:col-span-7 flex flex-col justify-center text-center lg:text-left">
            <span class="inline-block bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs px-3 py-1 rounded-full font-semibold tracking-wider mb-4 mx-auto lg:mx-0 w-fit">
                ★ ESPORTS RECRUITMENT 2026 ★
            </span>
            <h2 class="text-4xl md:text-5xl font-black tracking-tight text-white leading-tight mb-6">
                ก้าวข้ามขีดจำกัดเมอร์สู่ <br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-500">
                    นักกีฬาอีสปอร์ตรุ่นถัดไป
                </span>
            </h2>
            <p class="text-slate-400 text-base md:text-lg mb-8 leading-relaxed max-w-xl mx-auto lg:mx-0">
                Astra Gaming สังกัดอีสปอร์ตระดับเวิลด์คลาส กำลังตามหาดาวเด่นดวงใหม่เข้าร่วมทัพสู้ศึกระดับสากล ไม่สำคัญว่าคุณจะเล่น Valorant, RoV หรือ PUBG ขอเพียงคุณมี "ปฏิกิริยาการตอบสนองที่เหนือมนุษย์" 
                สมัครเข้าร่วมและทำการทดสอบระบบประสาทผ่านระบบ AI/AR ล่าสุดเพื่อพิสูจน์ฝีมือคุณวันนี้!
            </p>

            <!-- ข้อมูลความสำเร็จ / สถิติ -->
            <div class="grid grid-cols-3 gap-6 max-w-md mx-auto lg:mx-0 bg-slate-900/40 p-5 rounded-xl border border-slate-800/80">
                <div class="text-center">
                    <p class="text-2xl font-black text-white">12+</p>
                    <p class="text-[11px] text-slate-500 mt-1">ถ้วยรางวัลระดับประเทศ</p>
                </div>
                <div class="text-center border-x border-slate-800">
                    <p class="text-2xl font-black text-cyan-400">$2.5M+</p>
                    <p class="text-[11px] text-slate-500 mt-1">เงินรางวัลรวม</p>
                </div>
                <div class="text-center">
                    <p class="text-2xl font-black text-indigo-400">30+</p>
                    <p class="text-[11px] text-slate-500 mt-1">สตรีมเมอร์ & นักกีฬามืออาชีพ</p>
                </div>
            </div>
        </section>

        <!-- ฝั่งขวา: ฟอร์มล็อกอิน -->
        <section class="lg:col-span-5 bg-slate-900 border border-slate-800/80 p-8 rounded-2xl shadow-2xl relative overflow-hidden">
            <div class="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -z-10"></div>
            <div class="absolute bottom-0 left-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-3xl -z-10"></div>

            <div class="mb-6">
                <h3 class="text-xl font-bold text-white mb-2">เข้าสู่ระบบนักกีฬา</h3>
                <p class="text-xs text-slate-400">กรอกบัญชีผู้ใช้และรหัสผ่านเพื่อเข้าสู่ระบบทดสอบฝีมือ</p>
            </div>

            <!-- แสดง Error Message เมื่อ Login ไม่สำเร็จ -->
            <?php if (!empty($error_message)): ?>
                <div class="mb-5 bg-red-500/10 border border-red-500/30 text-red-400 text-xs p-3.5 rounded-lg flex items-center gap-2">
                    <span class="font-bold">⚠</span> <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST" class="space-y-4">
                <div>
                    <label for="username" class="block text-xs font-semibold text-slate-300 mb-1.5">ชื่อผู้ใช้งาน (Username)</label>
                    <input type="text" id="username" name="username" required placeholder="เช่น somchai_pro"
                           class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all">
                </div>

                <div>
                    <label for="password" class="block text-xs font-semibold text-slate-300 mb-1.5">รหัสผ่าน (Password)</label>
                    <input type="password" id="password" name="password" required placeholder="••••••••"
                           class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all">
                </div>

                <div class="pt-2">
                    <button type="submit" 
                            class="w-full bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-sm py-3 px-4 rounded-lg shadow-lg shadow-cyan-500/10 hover:shadow-cyan-500/25 transition-all">
                        เข้าสู่ระบบ
                    </button>
                </div>
            </form>

            <div class="mt-6 pt-6 border-t border-slate-800/80 text-center">
                <p class="text-xs text-slate-400 mb-3">ยังไม่ได้ลงทะเบียนเป็นสมาชิกสังกัดเราใช่หรือไม่?</p>
                <a href="register.php" 
                   class="inline-block w-full bg-slate-950 hover:bg-slate-800/80 text-cyan-400 border border-cyan-500/30 hover:border-cyan-400 font-bold text-xs py-2.5 px-4 rounded-lg transition-all">
                    ลงทะเบียนนักกีฬาใหม่
                </a>
            </div>
        </section>

    </main>

    <!-- Footer -->
    <footer class="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-600">
        <div class="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p>© 2026 Astra Gaming Esports Club. All Rights Reserved.</p>
            <p>ระบบรับสมัครนักกีฬารุ่นถัดไป (XAMPP Environment Supported)</p>
        </div>
    </footer>

</body>
</html>
