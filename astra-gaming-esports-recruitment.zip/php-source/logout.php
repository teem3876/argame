<?php
/**
 * logout.php - ไฟล์ออกจากระบบเพื่อทำลาย Session
 */

// เริ่มต้น Session
session_start();

// ล้างค่า Session ทั้งหมด
$_SESSION = array();

// ทำลาย Session คุกกี้ (ถ้ามี)
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// ทำลาย Session ในฝั่งเซิร์ฟเวอร์
session_destroy();

// ส่งผู้ใช้กลับไปยังหน้าแรก (Login)
header("Location: index.php");
exit();
?>
