<?php
/**
 * register.php - หน้าสมัครสมาชิกและสุ่มรหัส ID ประจำตัวนักกีฬา
 */

// เริ่มต้นใช้งาน Session
session_start();

// นำเข้าไฟล์เชื่อมต่อฐานข้อมูล
require_once 'db.php';

$success_athlete_id = "";
$success_fullname = "";
$error_message = "";

// ตรวจสอบเมื่อมีการกดส่งข้อมูลฟอร์มสมัครสมาชิก (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = trim($_POST['fullname']);
    $ign = trim($_POST['ign']);
    $age = intval($_POST['age']);
    $game = trim($_POST['game']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // ตรวจสอบความถูกต้องเบื้องต้น
    if (empty($fullname) || empty($ign) || empty($age) || empty($game) || empty($username) || empty($password)) {
        $error_message = "กรุณากรอกข้อมูลให้ครบถ้วนทุกช่อง";
    } elseif ($age < 12 || $age > 50) {
        $error_message = "อายุของนักกีฬาต้องอยู่ระหว่าง 12 ถึง 50 ปี";
    } else {
        try {
            // ตรวจสอบว่ามี Username นี้ซ้ำในฐานข้อมูลแล้วหรือยัง
            $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username");
            $check_stmt->execute(['username' => $username]);
            if ($check_stmt->fetch()) {
                $error_message = "ขออภัย! บัญชีผู้ใช้งานนี้ถูกใช้ในระบบไปแล้ว";
            } else {
                // ทำการสุ่มสร้างรหัส ID ประจำตัวนักกีฬา (รูปแบบ AS-XXXX)
                // ตรวจสอบให้มั่นใจว่ารหัสที่สุ่มได้ไม่ซ้ำกับใครในฐานข้อมูล
                $is_unique = false;
                $athlete_id = "";
                
                while (!$is_unique) {
                    $random_num = rand(1000, 9999);
                    $athlete_id = "AS-" . $random_num;
                    
                    $id_stmt = $pdo->prepare("SELECT id FROM users WHERE athlete_id = :athlete_id");
                    $id_stmt->execute(['athlete_id' => $athlete_id]);
                    if (!$id_stmt->fetch()) {
                        $is_unique = true;
                    }
                }

                // เข้ารหัสผ่านรหัสผ่านเพื่อความปลอดภัยของระบบ
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // บันทึกข้อมูลนักกีฬาลงในตาราง users
                $insert_stmt = $pdo->prepare("
                    INSERT INTO users (athlete_id, fullname, ign, age, game, username, password) 
                    VALUES (:athlete_id, :fullname, :ign, :age, :game, :username, :password)
                ");
                
                $insert_stmt->execute([
                    'athlete_id' => $athlete_id,
                    'fullname' => $fullname,
                    'ign' => $ign,
                    'age' => $age,
                    'game' => $game,
                    'username' => $username,
                    'password' => $hashed_password
                ]);

                // กำหนดสถานะสำเร็จเพื่อนำไปใช้แสดงการ์ดประตัวนักกีฬา
                $success_athlete_id = $athlete_id;
                $success_fullname = $fullname;
            }
        } catch (PDOException $e) {
            $error_message = "เกิดข้อผิดพลาดทางระบบ: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th" class="h-full bg-slate-950">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ลงทะเบียนนักกีฬาใหม่ - Astra Gaming</title>
    <!-- โหลด Tailwind CSS ผ่าน CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Anuphan:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Anuphan', sans-serif;
        }
    </style>
</head>
<body class="h-full text-slate-100 flex flex-col justify-between">

    <!-- Header -->
    <header class="border-b border-slate-800 bg-slate-900/50 backdrop-blur">
        <div class="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
            <a href="index.php" class="flex items-center gap-3 hover:opacity-80 transition-all">
                <div class="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-bold text-xl text-white shadow-lg">
                    A
                </div>
                <div>
                    <h1 class="font-bold text-lg leading-none text-white tracking-wider">ASTRA GAMING</h1>
                    <p class="text-[10px] text-cyan-400 font-medium tracking-widest mt-0.5">THE NEXT LEAGUE GENERATION</p>
                </div>
            </a>
            <a href="index.php" class="text-xs text-slate-400 hover:text-white transition-colors">ย้อนกลับไปหน้าแรก</a>
        </div>
    </header>

    <!-- Main Section -->
    <main class="max-w-4xl mx-auto px-6 py-12 flex-1 w-full flex items-center justify-center">

        <!-- กรณีลงทะเบียนสำเร็จแล้ว: แสดงการ์ด ID ประจำตัวนักกีฬาอย่างสวยงาม -->
        <?php if (!empty($success_athlete_id)): ?>
            <div class="w-full max-w-lg bg-slate-900 border-2 border-cyan-500/30 p-8 rounded-2xl shadow-2xl shadow-cyan-500/10 text-center relative overflow-hidden">
                <div class="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-tr from-cyan-500 to-indigo-500 rounded-full blur-3xl opacity-20"></div>
                <div class="absolute -bottom-10 -left-10 w-40 h-40 bg-gradient-to-tr from-purple-500 to-pink-500 rounded-full blur-3xl opacity-10"></div>

                <div class="w-16 h-16 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center justify-center text-3xl mx-auto mb-6">
                    ✓
                </div>

                <h2 class="text-2xl font-black text-white mb-2">ลงทะเบียนผู้สมัครสำเร็จ!</h2>
                <p class="text-xs text-slate-400 mb-6">ระบบสุ่มสร้างและเปิดใช้งานรหัสประจำตัวนักกีฬาของคุณแล้ว</p>

                <!-- การ์ดตัวตนดิจิทัลนักกีฬา -->
                <div class="bg-gradient-to-b from-slate-950 to-slate-900 border border-slate-800 rounded-xl p-6 text-left relative mb-8 overflow-hidden">
                    <div class="absolute top-3 right-4 text-[9px] font-mono text-slate-600 tracking-widest uppercase">Astra Member Card</div>
                    
                    <div class="flex items-center gap-4">
                        <div class="w-14 h-14 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-500 flex items-center justify-center text-2xl font-black text-white shadow-md">
                            AS
                        </div>
                        <div>
                            <p class="text-xs text-slate-500">ชื่อนักกีฬา</p>
                            <p class="text-lg font-bold text-white"><?php echo htmlspecialchars($success_fullname); ?></p>
                        </div>
                    </div>

                    <div class="mt-6 pt-5 border-t border-slate-800/60 grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-[10px] text-slate-500 uppercase tracking-wider">ATHLETE CODE</p>
                            <p id="athlete-code" class="text-xl font-mono font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400 mt-1"><?php echo $success_athlete_id; ?></p>
                        </div>
                        <div class="text-right">
                            <p class="text-[10px] text-slate-500 uppercase tracking-wider">STATUS</p>
                            <span class="inline-block bg-cyan-500/10 text-cyan-400 text-[10px] font-bold px-2 py-0.5 rounded border border-cyan-500/20 mt-1.5">
                                ACTIVE MEMBER
                            </span>
                        </div>
                    </div>
                </div>

                <p class="text-xs text-amber-400 mb-6 bg-amber-500/10 border border-amber-500/20 py-2 px-3 rounded-lg">
                    ⚠️ กรุณาจดจำรหัสผ่าน และรหัสประจำตัวด้านบนเพื่อเข้าสู่ระบบทดสอบ
                </p>

                <div class="flex flex-col sm:flex-row gap-3">
                    <button onclick="copyCode()" 
                            class="flex-1 bg-slate-950 hover:bg-slate-800 text-slate-300 font-semibold text-xs py-3 px-4 rounded-lg border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-center gap-2">
                        <svg class="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"></path></svg>
                        คัดลอกรหัสประจำตัว
                    </button>
                    <a href="index.php" 
                       class="flex-1 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-xs py-3 px-4 rounded-lg transition-all flex items-center justify-center">
                        กลับไปหน้าเข้าสู่ระบบ
                    </a>
                </div>

                <script>
                    function copyCode() {
                        var codeText = document.getElementById("athlete-code").innerText;
                        navigator.clipboard.writeText(codeText).then(function() {
                            alert("คัดลอกรหัสประจำตัว " + codeText + " ไปยังคลิปบอร์ดแล้ว!");
                        }, function() {
                            alert("เกิดข้อผิดพลาดในการคัดลอกรหัส กรุณาจดบันทึกด้วยมือ");
                        });
                    }
                </script>
            </div>

        <!-- กรณีหน้ากรอกฟอร์มปกติ -->
        <?php else: ?>
            <div class="w-full max-w-2xl bg-slate-900 border border-slate-800/80 p-8 rounded-2xl shadow-2xl relative">
                <div class="mb-8">
                    <span class="text-xs text-cyan-400 font-semibold tracking-widest uppercase">Join Our Legacy</span>
                    <h2 class="text-2xl font-black text-white mt-1">สมัครลงทะเบียนนักกีฬาใหม่</h2>
                    <p class="text-xs text-slate-400 mt-1">สร้างโปรไฟล์ดิจิทัลของคุณและเตรียมพร้อมทดสอบประสาทสัมผัส</p>
                </div>

                <!-- แสดงข้อความแจ้งเตือนข้อผิดพลาด -->
                <?php if (!empty($error_message)): ?>
                    <div class="mb-6 bg-red-500/10 border border-red-500/30 text-red-400 text-xs p-3.5 rounded-lg flex items-center gap-2">
                        <span class="font-bold">⚠</span> <?php echo htmlspecialchars($error_message); ?>
                    </div>
                <?php endif; ?>

                <form action="register.php" method="POST" class="space-y-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- ชื่อจริง นามสกุล -->
                        <div>
                            <label for="fullname" class="block text-xs font-semibold text-slate-300 mb-1.5">ชื่อจริง - นามสกุลจริง</label>
                            <input type="text" id="fullname" name="fullname" required placeholder="เช่น นายสมเกียรติ พลากร"
                                   class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all">
                        </div>

                        <!-- ชื่อในเกม (IGN) -->
                        <div>
                            <label for="ign" class="block text-xs font-semibold text-slate-300 mb-1.5">ชื่อในเกม (In-game Name)</label>
                            <input type="text" id="ign" name="ign" required placeholder="เช่น SLAYER_zZ"
                                   class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all">
                        </div>

                        <!-- อายุ -->
                        <div>
                            <label for="age" class="block text-xs font-semibold text-slate-300 mb-1.5">อายุ (ปี)</label>
                            <input type="number" id="age" name="age" required min="12" max="50" placeholder="เช่น 18"
                                   class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all">
                        </div>

                        <!-- เกมที่เชี่ยวชาญ -->
                        <div>
                            <label for="game" class="block text-xs font-semibold text-slate-300 mb-1.5">เกมที่เชี่ยวชาญสูงสุด</label>
                            <select id="game" name="game" required
                                    class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-all">
                                <option value="Valorant">Valorant</option>
                                <option value="RoV">RoV (Arena of Valor)</option>
                                <option value="PUBG">PUBG: BATTLEGROUNDS</option>
                                <option value="FreeFire">Free Fire</option>
                                <option value="Dota2">Dota 2</option>
                            </select>
                        </div>
                    </div>

                    <div class="border-t border-slate-800/80 pt-6">
                        <p class="text-xs font-bold text-cyan-400 mb-4 uppercase tracking-wider">ส่วนตั้งค่าบัญชีล็อกอิน</p>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- บัญชีล็อกอิน -->
                            <div>
                                <label for="username" class="block text-xs font-semibold text-slate-300 mb-1.5">ชื่อบัญชีผู้ใช้ (Username)</label>
                                <input type="text" id="username" name="username" required placeholder="ภาษาอังกฤษ/ตัวเลขเท่านั้น"
                                       class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all">
                            </div>

                            <!-- รหัสผ่าน -->
                            <div>
                                <label for="password" class="block text-xs font-semibold text-slate-300 mb-1.5">รหัสผ่าน (Password)</label>
                                <input type="password" id="password" name="password" required placeholder="ไม่ต่ำกว่า 6 ตัวอักษร"
                                       class="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all">
                            </div>
                        </div>
                    </div>

                    <div class="pt-4 flex flex-col sm:flex-row items-center gap-4">
                        <button type="submit"
                                class="w-full sm:w-auto flex-1 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-sm py-3 px-8 rounded-lg shadow-lg shadow-cyan-500/15 transition-all">
                            ส่งใบสมัคร & สร้างรหัสผ่านนักกีฬา
                        </button>
                        <a href="index.php" 
                           class="w-full sm:w-auto text-center bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 font-semibold text-xs py-3 px-6 rounded-lg transition-all">
                            ยกเลิก
                        </a>
                    </div>
                </form>
            </div>
        <?php endif; ?>

    </main>

    <!-- Footer -->
    <footer class="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-600">
        <div class="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
            <p>© 2026 Astra Gaming Esports Club. All Rights Reserved.</p>
            <p>ระบบสุ่ม ID ประจำตัวนักกีฬาอัตโนมัติความปลอดภัยสูง</p>
        </div>
    </footer>

</body>
</html>
