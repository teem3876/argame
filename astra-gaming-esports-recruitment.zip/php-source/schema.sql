-- คำสั่งสร้างฐานข้อมูลและตารางสำหรับระบบรับสมัครนักกีฬา Astra Gaming
-- สามารถคัดลอกไฟล์นี้ไปรันในเมนู SQL ของ phpMyAdmin ได้ทันที

-- 1. สร้างฐานข้อมูล (หากยังไม่มี)
CREATE DATABASE IF NOT EXISTS astra_gaming DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE astra_gaming;

-- 2. สร้างตารางสำหรับจัดเก็บข้อมูลนักกีฬาและผู้ใช้งาน
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    athlete_id VARCHAR(10) NOT NULL UNIQUE,     -- รหัสประจำตัวนักกีฬา (เช่น AS-1234)
    fullname VARCHAR(100) NOT NULL,            -- ชื่อ-นามสกุลจริง
    ign VARCHAR(50) NOT NULL,                  -- ชื่อในเกม (In-game Name)
    age INT NOT NULL,                          -- อายุ
    game VARCHAR(50) NOT NULL,                 -- เกมที่เชี่ยวชาญ (เช่น Valorant, RoV, PUBG)
    username VARCHAR(50) NOT NULL UNIQUE,      -- บัญชีผู้ใช้ในการเข้าสู่ระบบ
    password VARCHAR(255) NOT NULL,            -- รหัสผ่าน (เก็บแบบเข้ารหัสความปลอดภัย)
    high_score INT DEFAULT 0,                  -- คะแนนปฏิกิริยาสูงสุดที่ทำได้
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP -- วันเวลาที่สมัครสมาชิก
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. เพิ่มข้อมูลตัวอย่าง (Optional) สำหรับการทดสอบ
-- รหัสผ่านคือ "123456" ซึ่งถูกเข้ารหัสด้วย PASSWORD_DEFAULT (bcrypt)
INSERT INTO users (athlete_id, fullname, ign, age, game, username, password, high_score) 
VALUES 
('AS-1111', 'สมชาย ยอดนักรบ', 'MortalKombat', 21, 'Valorant', 'somchai', '$2y$10$tZ2EunD8V.7410C7A1mPKeSg8.vOskhU5iN2q0nE3M6Ffe5m2A/P6', 15),
('AS-2222', 'จิราภรณ์ สายซัพ', 'AstraWitch', 19, 'RoV', 'jiraporn', '$2y$10$tZ2EunD8V.7410C7A1mPKeSg8.vOskhU5iN2q0nE3M6Ffe5m2A/P6', 22);
