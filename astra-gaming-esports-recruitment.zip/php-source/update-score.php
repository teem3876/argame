<?php
/**
 * update-score.php - ตัวประมวลผลเซิร์ฟเวอร์แบบเบื้องหลัง (Fetch API)
 * เพื่ออัปเดตคะแนน High Score ของนักกีฬาผู้ล็อกอินอยู่
 */

// ส่ง Header กลับเป็น JSON
header('Content-Type: application/json; charset=utf-8');

// เริ่มต้น Session
session_start();

// นำเข้าไฟล์ฐานข้อมูล
require_once 'db.php';

// ตรวจสอบการเข้าสู่ระบบ หากไม่ผ่านให้ตอบกลับปฏิเสธสิทธิ์
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'ไม่ได้รับสิทธิ์การทำงาน กรุณาเข้าสู่ระบบก่อน'
    ]);
    exit();
}

// ตรวจสอบว่าเป็นการส่งข้อมูลด้วย POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'โปรโตคอลการร้องขอไม่ถูกต้อง ต้องใช้ POST เท่านั้น'
    ]);
    exit();
}

// รับข้อมูลดิบจากเนื้อหาของคำร้องขอ (JSON body)
$json_raw = file_get_contents('php://input');
$data = json_decode($json_raw, true);

// ดึงค่าคะแนนรอบล่าสุดและตรวจสอบความถูกต้อง
$new_score = isset($data['score']) ? intval($data['score']) : null;
$user_id = $_SESSION['user_id'];

if ($new_score === null || $new_score < 0) {
    echo json_encode([
        'status' => 'error',
        'message' => 'รูปแบบคะแนนไม่ถูกต้อง'
    ]);
    exit();
}

try {
    // ดึงคะแนนสูงสุดเดิมในฐานข้อมูลมาตรวจสอบความแน่ใจอีกครั้ง
    $stmt = $pdo->prepare("SELECT high_score FROM users WHERE id = :id");
    $stmt->execute(['id' => $user_id]);
    $user = $stmt->fetch();
    
    if (!$user) {
        echo json_encode([
            'status' => 'error',
            'message' => 'ไม่พบข้อมูลบัญชีผู้ใช้งานในระบบ'
        ]);
        exit();
    }
    
    $current_high_score = intval($user['high_score']);
    
    // อัปเดตเฉพาะกรณีที่คะแนนรอบล่าสุด "มากกว่า" คะแนนสูงสุดเดิมเท่านั้น
    if ($new_score > $current_high_score) {
        $update_stmt = $pdo->prepare("UPDATE users SET high_score = :high_score WHERE id = :id");
        $update_stmt->execute([
            'high_score' => $new_score,
            'id' => $user_id
        ]);
        
        echo json_encode([
            'status' => 'success',
            'message' => 'อัปเดตสถิติใหม่สูงสุดเรียบร้อย!',
            'old_score' => $current_high_score,
            'new_score' => $new_score
        ]);
    } else {
        echo json_encode([
            'status' => 'no_change',
            'message' => 'คะแนนล่าสุดไม่ทำลายสถิติเดิม',
            'current_high' => $current_high_score,
            'received' => $new_score
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'เกิดข้อผิดพลาดในการอัปเดตฐานข้อมูล: ' . $e->getMessage()
    ]);
}
?>
