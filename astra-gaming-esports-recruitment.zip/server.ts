import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;
const DATABASE_FILE = path.join(process.cwd(), "database.json");

// Middleware to parse JSON bodies
app.use(express.json());

// Helper to read database
function readDB() {
  if (!fs.existsSync(DATABASE_FILE)) {
    // Initial Seed Data matching the SQL schema
    const initialData = [
      {
        id: 1,
        athlete_id: "AS-1111",
        fullname: "สมชาย ยอดนักรบ",
        ign: "MortalKombat",
        age: 21,
        game: "Valorant",
        username: "somchai",
        password: "password123", // For mock preview ease, we check password directly
        high_score: 15,
      },
      {
        id: 2,
        athlete_id: "AS-2222",
        fullname: "จิราภรณ์ สายซัพ",
        ign: "AstraWitch",
        age: 19,
        game: "RoV",
        username: "jiraporn",
        password: "password123",
        high_score: 22,
      },
    ];
    fs.writeFileSync(DATABASE_FILE, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  try {
    const raw = fs.readFileSync(DATABASE_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (e) {
    return [];
  }
}

// Helper to write database
function writeDB(data: any) {
  fs.writeFileSync(DATABASE_FILE, JSON.stringify(data, null, 2));
}

// Simulated active session in-memory for preview
let currentSessionUser: any = null;

// API Routes
app.get("/api/session", (req, res) => {
  res.json({ user: currentSessionUser });
});

app.post("/api/login", (req, res) => {
  const { username, password } = req.body;
  const users = readDB();
  const user = users.find(
    (u: any) =>
      u.username.toLowerCase() === username.trim().toLowerCase() &&
      u.password === password
  );

  if (user) {
    currentSessionUser = {
      id: user.id,
      athlete_id: user.athlete_id,
      fullname: user.fullname,
      ign: user.ign,
      age: user.age,
      game: user.game,
      username: user.username,
      high_score: user.high_score,
    };
    res.json({ status: "success", user: currentSessionUser });
  } else {
    res.status(401).json({ status: "error", message: "บัญชีผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
  }
});

app.post("/api/register", (req, res) => {
  const { fullname, ign, age, game, username, password } = req.body;
  const users = readDB();

  // Check if username exists
  const exists = users.some(
    (u: any) => u.username.toLowerCase() === username.trim().toLowerCase()
  );
  if (exists) {
    return res.status(400).json({ status: "error", message: "ขออภัย! บัญชีผู้ใช้งานนี้ถูกใช้ในระบบไปแล้ว" });
  }

  // Generate AS-XXXX ID
  let isUnique = false;
  let athlete_id = "";
  while (!isUnique) {
    const randNum = Math.floor(1000 + Math.random() * 9000);
    athlete_id = `AS-${randNum}`;
    if (!users.some((u: any) => u.athlete_id === athlete_id)) {
      isUnique = true;
    }
  }

  const newUser = {
    id: users.length > 0 ? Math.max(...users.map((u: any) => u.id)) + 1 : 1,
    athlete_id,
    fullname,
    ign,
    age: parseInt(age),
    game,
    username,
    password,
    high_score: 0,
  };

  users.push(newUser);
  writeDB(users);

  res.json({ status: "success", user: newUser });
});

app.post("/api/update-score", (req, res) => {
  if (!currentSessionUser) {
    return res.status(401).json({ status: "error", message: "กรุณาเข้าสู่ระบบก่อน" });
  }

  const { score } = req.body;
  const newScore = parseInt(score);
  const users = readDB();
  const userIndex = users.findIndex((u: any) => u.id === currentSessionUser.id);

  if (userIndex !== -1) {
    const currentHigh = users[userIndex].high_score;
    if (newScore > currentHigh) {
      users[userIndex].high_score = newScore;
      writeDB(users);
      currentSessionUser.high_score = newScore;
      res.json({ status: "success", old_score: currentHigh, new_score: newScore });
    } else {
      res.json({ status: "no_change", current_high: currentHigh, received: newScore });
    }
  } else {
    res.status(404).json({ status: "error", message: "ไม่พบผู้ใช้ในระบบ" });
  }
});

app.post("/api/logout", (req, res) => {
  currentSessionUser = null;
  res.json({ status: "success" });
});

// Endpoint to load the content of PHP files for the interactive viewer
app.get("/api/php-source", (req, res) => {
  const files = [
    { name: "schema.sql", path: "php-source/schema.sql" },
    { name: "db.php", path: "php-source/db.php" },
    { name: "index.php", path: "php-source/index.php" },
    { name: "register.php", path: "php-source/register.php" },
    { name: "ar-game.php", path: "php-source/ar-game.php" },
    { name: "update-score.php", path: "php-source/update-score.php" },
    { name: "logout.php", path: "php-source/logout.php" },
  ];

  try {
    const sources = files.map((f) => {
      const fullPath = path.join(process.cwd(), f.path);
      const content = fs.existsSync(fullPath)
        ? fs.readFileSync(fullPath, "utf-8")
        : "File not found";
      return {
        name: f.name,
        path: f.path,
        content,
      };
    });
    res.json(sources);
  } catch (error) {
    res.status(500).json({ error: "Failed to read source files" });
  }
});

// Setup Vite or Static File Server
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
