import { useState, useEffect } from "react";
import { User } from "./types";
import LandingView from "./components/LandingView";
import RegisterView from "./components/RegisterView";
import GameView from "./components/GameView";
import SourceCodeViewer from "./components/SourceCodeViewer";
import { LogOut, ArrowLeft, Code2, Sparkles, CheckCircle2 } from "lucide-react";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeView, setActiveView] = useState<"landing" | "register" | "game">("landing");
  const [showCodeViewer, setShowCodeViewer] = useState<boolean>(false);
  const [checkingSession, setCheckingSession] = useState<boolean>(true);

  // Check session on mount
  useEffect(() => {
    fetch("/api/session")
      .then((res) => res.json())
      .then((data) => {
        if (data.user) {
          setUser(data.user);
          setActiveView("game");
        }
      })
      .catch((e) => console.log("No active session found"))
      .finally(() => setCheckingSession(false));
  }, []);

  const handleLoginSuccess = (loggedInUser: User) => {
    setUser(loggedInUser);
    setActiveView("game");
  };

  const handleLogout = async () => {
    try {
      await fetch("/api/logout", { method: "POST" });
    } catch (e) {}
    setUser(null);
    setActiveView("landing");
  };

  const handleHighScoreUpdated = (newScore: number) => {
    if (user) {
      setUser({ ...user, high_score: newScore });
    }
  };

  if (checkingSession) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400 gap-3">
        <div className="w-10 h-10 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-xs font-semibold tracking-wider text-slate-500">กำลังเชื่อมต่อฐานข้อมูลตัวอย่าง...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#070a13] text-slate-100 flex flex-col justify-between font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      
      {/* Upper Glowing Orbs (Atmospheric background) */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-[120px] -z-10 pointer-events-none"></div>
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-[120px] -z-10 pointer-events-none"></div>

      {/* Header */}
      <header className="border-b border-slate-800/80 bg-slate-900/40 backdrop-blur sticky top-0 z-40 transition-all">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          
          {/* Logo */}
          <button 
            onClick={() => {
              if (activeView !== "game") {
                setActiveView("landing");
              }
            }}
            className="flex items-center gap-3 text-left focus:outline-none hover:opacity-90 transition-all"
          >
            <div className="w-10 h-10 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center font-bold text-xl text-white shadow-lg shadow-indigo-500/10">
              A
            </div>
            <div>
              <h1 className="font-bold text-lg leading-none text-white tracking-wider font-mono">ASTRA GAMING</h1>
              <p className="text-[9px] text-cyan-400 font-bold tracking-widest mt-0.5">THE NEXT LEAGUE GENERATION</p>
            </div>
          </button>

          {/* User actions / View links */}
          <div className="flex items-center gap-4">
            
            {/* Source code viewer toggle */}
            <button
              id="code-toggle-btn"
              onClick={() => setShowCodeViewer(!showCodeViewer)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold border transition-all ${
                showCodeViewer
                  ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/40"
                  : "bg-slate-900 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700"
              }`}
            >
              <Code2 className="w-4 h-4 text-cyan-400" />
              <span>{showCodeViewer ? "ซ่อนพอร์ทัล PHP Source" : "ดูซอร์สโค้ด PHP/MySQL (XAMPP)"}</span>
            </button>

            {/* Logout button (only if logged in) */}
            {activeView === "game" && user && (
              <div className="flex items-center gap-4 pl-4 border-l border-slate-800">
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] text-slate-500">นักกีฬา</p>
                  <p className="text-xs font-bold text-white flex items-center gap-1">
                    {user.fullname} 
                    <span className="text-cyan-400 font-mono">({user.ign})</span>
                  </p>
                </div>
                <button
                  onClick={handleLogout}
                  className="bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-400 px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>ออกจากระบบ</span>
                </button>
              </div>
            )}
          </div>

        </div>
      </header>

      {/* Main Layout Workspace */}
      <main className="max-w-7xl mx-auto px-6 py-12 flex-1 w-full flex flex-col justify-center">
        
        {/* Notice/Alert for XAMPP Source Code */}
        {!showCodeViewer && (
          <div className="mb-8 max-w-7xl mx-auto w-full bg-indigo-500/10 border border-indigo-500/20 py-3.5 px-5 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-5 h-5 text-indigo-400 flex-shrink-0" />
              <div className="text-xs">
                <p className="font-bold text-indigo-300">💡 พรีวิวจำลองระบบแบบ Full-Stack สมบูรณ์แบบ</p>
                <p className="text-slate-400 mt-0.5">คุณสามารถสมัครสมาชิกและเข้าเล่นเพื่อทดสอบระบบเก็บคะแนน High Score ได้จริงในหน้าจอนี้!</p>
              </div>
            </div>
            <button
              onClick={() => setShowCodeViewer(true)}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 hover:underline transition-all flex items-center gap-1 self-end sm:self-auto"
            >
              ดูคู่มือและสคริปต์เชื่อมต่อ XAMPP / PHP ที่นี่
              <ArrowLeft className="w-3.5 h-3.5 rotate-180" />
            </button>
          </div>
        )}

        {showCodeViewer ? (
          /* Code Viewer Console Panel */
          <div className="space-y-6">
            <div className="flex justify-between items-center bg-slate-900/60 p-4 rounded-xl border border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-xs font-bold text-slate-300">พอร์ทัลดูซอร์สโค้ด PHP/MySQL สั่งรันบน XAMPP</span>
              </div>
              <button
                onClick={() => setShowCodeViewer(false)}
                className="text-xs font-semibold text-slate-400 hover:text-white transition-colors flex items-center gap-1"
              >
                <ArrowLeft className="w-4 h-4" />
                ย้อนกลับไปหน้าจำลองระบบ
              </button>
            </div>
            <SourceCodeViewer />
          </div>
        ) : (
          /* Running Interactive Preview App */
          <div className="transition-all duration-300">
            {activeView === "landing" && (
              <LandingView
                onLoginSuccess={handleLoginSuccess}
                onNavigateToRegister={() => setActiveView("register")}
              />
            )}

            {activeView === "register" && (
              <RegisterView
                onNavigateToLogin={() => setActiveView("landing")}
              />
            )}

            {activeView === "game" && user && (
              <GameView
                user={user}
                onLogout={handleLogout}
                onHighScoreUpdated={handleHighScoreUpdated}
              />
            )}
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/40 py-6 text-center text-xs text-slate-500 relative">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 Astra Gaming Esports Club. Crafted with React, Express, PHP & MySQL (XAMPP Compatibility).</p>
          <div className="flex gap-4 text-slate-600">
            <span>Thai language encoding supported (Anuphan Webfont)</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
