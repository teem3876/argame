import { useState, useEffect, useRef, MouseEvent } from "react";
import { User } from "../types";
import { LogOut, Play, RefreshCw, Trophy, Camera, HelpCircle, Gamepad2, Info } from "lucide-react";

interface GameViewProps {
  user: User;
  onLogout: () => void;
  onHighScoreUpdated: (newScore: number) => void;
}

export default function GameView({ user, onLogout, onHighScoreUpdated }: GameViewProps) {
  // Game states
  const [localScore, setLocalScore] = useState(0);
  const [highScore, setHighScore] = useState(user.high_score);
  const [timeLeft, setTimeLeft] = useState(30);
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameover, setGameover] = useState(false);
  const [isNewRecord, setIsNewRecord] = useState(false);
  const [statusMessage, setStatusMessage] = useState("● รอการเริ่มต้นทดสอบ...");
  const [statusColor, setStatusColor] = useState("text-amber-400");
  
  // Settings & fallback
  const [fallbackMode, setFallbackMode] = useState(false);
  const [loadingEngine, setLoadingEngine] = useState(true);
  const [engineError, setEngineError] = useState(false);

  // Refs for tracking
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  
  // Game loop variables
  const starPos = useRef({ x: 150, y: 150, radius: 24 });
  const pointerPos = useRef({ x: -100, y: -100, radius: 15, isDetected: false });
  const animationFrameId = useRef<number | null>(null);
  const timerIntervalId = useRef<NodeJS.Timeout | null>(null);
  
  // MediaPipe state
  const handsModelRef = useRef<any>(null);
  const cameraObjRef = useRef<any>(null);

  // Sound generator using Web Audio API
  const playBeep = (frequency: number, duration: number) => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const audioCtx = new AudioContextClass();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(frequency, audioCtx.currentTime);
      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + duration);
    } catch (e) {
      console.warn("Beep failed", e);
    }
  };

  // Helper to load external scripts dynamically
  const loadScript = (src: string): Promise<void> => {
    return new Promise((resolve, reject) => {
      if (document.querySelector(`script[src="${src}"]`)) {
        resolve();
        return;
      }
      const script = document.createElement("script");
      script.src = src;
      script.async = true;
      script.onload = () => resolve();
      script.onerror = () => reject();
      document.body.appendChild(script);
    });
  };

  // Load MediaPipe scripts on mount
  useEffect(() => {
    let mounted = true;
    
    const initMediaPipe = async () => {
      try {
        await loadScript("https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js");
        await loadScript("https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js");
        
        if (!mounted) return;

        const HandsClass = (window as any).Hands;
        const CameraClass = (window as any).Camera;

        if (!HandsClass || !CameraClass) {
          throw new Error("MediaPipe script elements did not load global constructors correctly");
        }

        // Initialize MediaPipe Hands model
        const hands = new HandsClass({
          locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
        });

        hands.setOptions({
          maxNumHands: 1,
          modelComplexity: 1,
          minDetectionConfidence: 0.6,
          minTrackingConfidence: 0.6,
        });

        hands.onResults((results: any) => {
          if (fallbackMode || !isPlaying) return;

          if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
            pointerPos.current.isDetected = true;
            // Landmark index 8 is the index finger tip
            const indexFingerTip = results.multiHandLandmarks[0][8];
            const canvas = canvasRef.current;
            if (canvas) {
              pointerPos.current.x = Math.floor(indexFingerTip.x * canvas.width);
              pointerPos.current.y = Math.floor(indexFingerTip.y * canvas.height);
              checkCollision();
            }
          } else {
            pointerPos.current.isDetected = false;
          }
        });

        handsModelRef.current = hands;

        // Initialize Camera
        if (videoRef.current) {
          const camera = new CameraClass(videoRef.current, {
            onFrame: async () => {
              if (!fallbackMode && handsModelRef.current) {
                await handsModelRef.current.send({ image: videoRef.current! });
              }
            },
            width: 640,
            height: 480,
          });

          await camera.start();
          cameraObjRef.current = camera;
        }

        setLoadingEngine(false);
        setStatusMessage("● กล้องพร้อมใช้งาน และเชื่อมต่อระบบ AI AR แล้ว");
        setStatusColor("text-emerald-400");
      } catch (err) {
        console.warn("Could not load camera/MediaPipe. Switching to Mouse Fallback.", err);
        if (mounted) {
          setEngineError(true);
          setLoadingEngine(false);
          enableFallback();
        }
      }
    };

    initMediaPipe();

    return () => {
      mounted = false;
      // Stop webcam and loops on unmount
      if (cameraObjRef.current) {
        try {
          cameraObjRef.current.stop();
        } catch (e) {}
      }
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
      if (timerIntervalId.current) {
        clearInterval(timerIntervalId.current);
      }
    };
  }, [fallbackMode, isPlaying]);

  const enableFallback = () => {
    setFallbackMode(true);
    setStatusMessage("● ทำงานบนโหมดทดสอบเมาส์สัมผัสหน้าจอ");
    setStatusColor("text-cyan-400 font-bold animate-pulse");
  };

  const handleToggleMode = () => {
    if (fallbackMode) {
      setFallbackMode(false);
      setStatusMessage("● รอวิเคราะห์กล้องเว็บแคม...");
      setStatusColor("text-amber-400");
      setLoadingEngine(true);
    } else {
      enableFallback();
    }
  };

  // Star drawing helper
  const drawStarShape = (
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    spikes: number,
    outerRadius: number,
    innerRadius: number
  ) => {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    const step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
    ctx.fillStyle = "#fbbf24";
    ctx.fill();
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 1.5;
    ctx.stroke();
  };

  // Render Loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const render = () => {
      ctx.save();
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!fallbackMode && videoRef.current && videoRef.current.readyState >= 2) {
        // Draw webcam image mirrored
        ctx.scale(-1, 1);
        ctx.drawImage(videoRef.current, -canvas.width, 0, canvas.width, canvas.height);
        ctx.scale(-1, 1); // Reset scale
      } else {
        // Draw cyberpunk matrix background
        ctx.fillStyle = "#090d16";
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        // Draw network grid lines
        ctx.strokeStyle = "#121a2c";
        ctx.lineWidth = 1;
        for (let i = 0; i < canvas.width; i += 40) {
          ctx.beginPath();
          ctx.moveTo(i, 0);
          ctx.lineTo(i, canvas.height);
          ctx.stroke();
        }
        for (let j = 0; j < canvas.height; j += 40) {
          ctx.beginPath();
          ctx.moveTo(0, j);
          ctx.lineTo(canvas.width, j);
          ctx.stroke();
        }
      }

      // Draw Gold Star
      if (isPlaying) {
        const pulse = Math.abs(Math.sin(Date.now() * 0.005)) * 10;
        const gradient = ctx.createRadialGradient(
          starPos.current.x,
          starPos.current.y,
          2,
          starPos.current.x,
          starPos.current.y,
          starPos.current.radius + pulse
        );
        gradient.addColorStop(0, "rgba(251, 191, 36, 0.9)");
        gradient.addColorStop(0.3, "rgba(251, 191, 36, 0.4)");
        gradient.addColorStop(1, "rgba(251, 191, 36, 0)");

        ctx.beginPath();
        ctx.fillStyle = gradient;
        ctx.arc(starPos.current.x, starPos.current.y, starPos.current.radius + pulse, 0, 2 * Math.PI);
        ctx.fill();

        drawStarShape(
          ctx,
          starPos.current.x,
          starPos.current.y,
          5,
          starPos.current.radius - 6,
          starPos.current.radius / 2 - 3
        );
      }

      // Draw player pointer
      if (pointerPos.current.isDetected || fallbackMode) {
        ctx.beginPath();
        ctx.strokeStyle = "#22d3ee";
        ctx.lineWidth = 2;
        ctx.arc(pointerPos.current.x, pointerPos.current.y, pointerPos.current.radius, 0, 2 * Math.PI);
        ctx.stroke();

        ctx.beginPath();
        ctx.fillStyle = "#06b6d4";
        ctx.arc(pointerPos.current.x, pointerPos.current.y, 5, 0, 2 * Math.PI);
        ctx.fill();
      }

      ctx.restore();
      animationFrameId.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationFrameId.current) {
        cancelAnimationFrame(animationFrameId.current);
      }
    };
  }, [fallbackMode, isPlaying]);

  // Handle mouse movement for fallback mode
  const handleMouseMove = (e: MouseEvent<HTMLCanvasElement>) => {
    if (!fallbackMode) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    // Map mouse screen coords to 640x480 resolution
    pointerPos.current.x = (e.clientX - rect.left) * (canvas.width / rect.width);
    pointerPos.current.y = (e.clientY - rect.top) * (canvas.height / rect.height);

    checkCollision();
  };

  const spawnStar = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const margin = 50;
    starPos.current.x = Math.floor(margin + Math.random() * (canvas.width - margin * 2));
    starPos.current.y = Math.floor(margin + Math.random() * (canvas.height - margin * 2));
  };

  const checkCollision = () => {
    if (!isPlaying) return;
    
    // Map coords in standard camera (non-mirrored on X since we handle draw mirrored)
    let pointerX = pointerPos.current.x;
    if (!fallbackMode && canvasRef.current) {
      // In mirrored cam, pointer raw X needs mirroring
      pointerX = canvasRef.current.width - pointerX;
    }

    const dist = Math.hypot(pointerX - starPos.current.x, pointerPos.current.y - starPos.current.y);
    if (dist < starPos.current.radius + pointerPos.current.radius) {
      setLocalScore((prev) => {
        const next = prev + 1;
        playBeep(650, 0.12);
        spawnStar();
        return next;
      });
    }
  };

  const startGame = () => {
    if (isPlaying) return;

    setLocalScore(0);
    setTimeLeft(30);
    setIsPlaying(true);
    setGameover(false);
    setIsNewRecord(false);
    spawnStar();

    playBeep(440, 0.1);
    setTimeout(() => playBeep(520, 0.1), 120);

    setStatusMessage("⚡ การทดสอบปฏิกิริยามือประสานตากำลังดำเนินการ!");
    setStatusColor("text-emerald-400 font-bold animate-pulse");

    timerIntervalId.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerIntervalId.current!);
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const endGame = () => {
    setIsPlaying(false);
    setGameover(true);
    setStatusMessage("● จบการทดสอบการปฏิกิริยา");
    setStatusColor("text-rose-500 font-semibold");

    playBeep(220, 0.2);
    setTimeout(() => playBeep(290, 0.3), 200);

    // Save score if it beats high score
    setLocalScore((score) => {
      if (score > highScore) {
        setIsNewRecord(true);
        saveHighScore(score);
      }
      return score;
    });
  };

  const saveHighScore = async (score: number) => {
    try {
      const res = await fetch("/api/update-score", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ score }),
      });
      const data = await res.json();
      if (data.status === "success") {
        setHighScore(score);
        onHighScoreUpdated(score);
      }
    } catch (e) {
      console.error("Failed to update high score", e);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
      {/* Left: Stats & Instructions */}
      <div className="lg:col-span-4 flex flex-col gap-6">
        
        {/* Stats Card */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <h3 className="text-xs text-slate-400 font-semibold tracking-widest uppercase mb-4 flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-500" />
            ข้อมูลคะแนนและสถิติ
          </h3>

          <div className="grid grid-cols-2 gap-4">
            {/* Current Score */}
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-center">
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">คะแนนรอบนี้</p>
              <p className="text-4xl font-black text-cyan-400 font-mono mt-1">{localScore}</p>
            </div>

            {/* High Score */}
            <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-center relative overflow-hidden">
              <div className="absolute -top-6 -right-6 w-12 h-12 bg-amber-500/10 rounded-full blur"></div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">สถิติสูงสุด (High Score)</p>
              <p className="text-4xl font-black text-amber-400 font-mono mt-1">{highScore}</p>
            </div>
          </div>

          {/* Time Countdown */}
          <div className="mt-6">
            <div className="flex justify-between text-xs font-bold text-slate-400 mb-1.5 uppercase">
              <span>เวลาที่เหลือ</span>
              <span className="text-rose-400 font-mono">{timeLeft} วินาที</span>
            </div>
            <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
              <div
                className="bg-rose-500 h-full transition-all duration-100"
                style={{ width: `${(timeLeft / 30) * 100}%` }}
              ></div>
            </div>
          </div>
        </div>

        {/* Rules & Fallback Switch */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl flex-1 flex flex-col justify-between gap-6">
          <div>
            <h3 className="text-xs text-slate-400 font-semibold tracking-widest uppercase mb-4 flex items-center gap-1.5">
              <HelpCircle className="w-4 h-4 text-indigo-400" />
              วิธีการเข้ารับการทดสอบ
            </h3>
            <ul className="space-y-4 text-xs text-slate-300">
              <li className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono font-bold flex items-center justify-center flex-shrink-0">1</span>
                <span>อนุญาตให้เว็บเข้าถึง<b>กล้องถ่ายภาพ</b>เพื่อเปิดใช้งานระบบตรวจจับฝ่ามือ AR</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono font-bold flex items-center justify-center flex-shrink-0">2</span>
                <span>ขยับฝ่ามือ/นิ้วชี้หน้ากล้องเพื่อเลื่อนวงแหวนสแกนไป<b>สัมผัสโดนดาวสีทอง</b>เพื่อเก็บคะแนน</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-cyan-500/10 text-cyan-400 font-mono font-bold flex items-center justify-center flex-shrink-0">3</span>
                <span>ทำคะแนนให้ได้มากที่สุดภายใน <b>30 วินาที</b> เพื่อทำลายสถิติสูงสุดและอัปเดตลงเซิร์ฟเวอร์</span>
              </li>
            </ul>
          </div>

          <div className="pt-4 border-t border-slate-800/80">
            <div className="flex items-center gap-2 text-slate-500 text-[11px] mb-3 leading-relaxed">
              <Info className="w-4 h-4 text-slate-400 flex-shrink-0" />
              <span>หากไม่มีเว็บกล้อง หรือกล้องตรวจไม่พบ สามารถเปลี่ยนมาสัมผัสผ่านเมาส์ได้ที่นี่</span>
            </div>
            <button
              onClick={handleToggleMode}
              className="w-full bg-slate-950 hover:bg-slate-800 text-slate-300 border border-slate-800 hover:border-slate-700 font-semibold text-xs py-2.5 rounded-lg transition-all flex items-center justify-center gap-2"
            >
              <Gamepad2 className="w-4 h-4 text-cyan-400" />
              {fallbackMode ? "✨ คืนค่าใช้งานกล้อง Webcamera" : "🎮 สลับเป็นโหมดเล่นด้วยเมาส์"}
            </button>
          </div>
        </div>

      </div>

      {/* Right: AR Canvas / Webcam View */}
      <div className="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col overflow-hidden relative min-h-[440px]">
        {/* Controls */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/20">
          <span className={`text-xs font-semibold flex items-center gap-2 ${statusColor}`}>
            {statusMessage}
          </span>
          <button
            onClick={startGame}
            disabled={isPlaying}
            className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-bold text-xs py-2 px-5 rounded-lg transition-all shadow-md shadow-emerald-500/10 flex items-center gap-1.5 disabled:opacity-40"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            เริ่มการทดสอบ (START)
          </button>
        </div>

        {/* Hidden Camera element for MediaPipe process */}
        <video
          ref={videoRef}
          style={{ display: "none" }}
          autoPlay
          playsInline
          muted
        ></video>

        {/* Arena canvas */}
        <div className="flex-1 w-full bg-slate-950 relative flex items-center justify-center overflow-hidden">
          <canvas
            ref={canvasRef}
            width={640}
            height={480}
            onMouseMove={handleMouseMove}
            className={`max-w-full h-auto rounded-lg shadow-inner ${
              fallbackMode ? "" : "transform scale-x-[-1]"
            }`}
          ></canvas>

          {/* Engine Loading Overlay */}
          {!fallbackMode && loadingEngine && (
            <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center gap-4 text-center p-6">
              <div className="w-10 h-10 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
              <div>
                <p className="text-sm font-bold text-white">กำลังเปิดกล้องเว็บแคมและดาวน์โหลดสมองกล (AI AR Engine)...</p>
                <p className="text-xs text-slate-500 mt-1">กรุณารออนุมัติกล้องหรือคลิก "โหมดเมาส์" ทางซ้ายเพื่อทดสอบได้ทันที</p>
              </div>
            </div>
          )}

          {/* GameOver Overlay */}
          {gameover && (
            <div className="absolute inset-0 bg-slate-950/95 flex items-center justify-center p-6">
              <div className="max-w-sm w-full bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-2xl text-center relative">
                <div className="w-16 h-16 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center justify-center text-3xl mx-auto mb-4 animate-bounce">
                  ⏱
                </div>
                <h4 class="text-2xl font-black text-white">หมดเวลาทดสอบ!</h4>
                <p className="text-xs text-slate-400 mt-1">สรุปการทดสอบปฏิกิริยาและประสาทการรับรู้</p>

                <div className="my-6 bg-slate-950/60 p-5 rounded-xl border border-slate-800/80">
                  <p className="text-sm text-slate-400">คะแนนที่คุณทำได้</p>
                  <p className="text-5xl font-mono font-black text-cyan-400 mt-1">{localScore}</p>
                  
                  {isNewRecord && (
                    <p className="text-xs font-bold text-emerald-400 mt-3 animate-pulse">
                      🎉 ยอดเยี่ยม! คุณสร้างสถิติสูงสุดใหม่สำเร็จ!
                    </p>
                  )}
                </div>

                <button
                  onClick={startGame}
                  className="w-full bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-xs py-3 rounded-lg transition-all flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="w-4 h-4 animate-spin-slow" />
                  ทำการทดสอบใหม่อีกรอบ
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
