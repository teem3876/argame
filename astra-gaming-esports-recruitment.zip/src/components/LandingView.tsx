import { useState, FormEvent } from "react";
import { User } from "../types";
import { LogIn, UserPlus, ShieldAlert, Award, Star, Users } from "lucide-react";

interface LandingViewProps {
  onLoginSuccess: (user: User) => void;
  onNavigateToRegister: () => void;
}

export default function LandingView({
  onLoginSuccess,
  onNavigateToRegister,
}: LandingViewProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();

      if (res.ok && data.status === "success") {
        onLoginSuccess(data.user);
      } else {
        setError(data.message || "การเข้าสู่ระบบล้มเหลว กรุณาลองใหม่อีกครั้ง");
      }
    } catch (err) {
      setError("ไม่สามารถติดต่อเซิร์ฟเวอร์ระบบได้ กรุณาลองอีกครั้ง");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
      {/* Left: Organization Showcase */}
      <div className="lg:col-span-7 flex flex-col justify-center text-center lg:text-left">
        <span className="inline-block bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-xs px-3.5 py-1 rounded-full font-bold tracking-wider mb-5 mx-auto lg:mx-0 w-fit">
          ★ ESPORTS RECRUITMENT 2026 ★
        </span>
        
        <h2 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight mb-6">
          ก้าวข้ามขีดจำกัดเมอร์สู่ <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-500">
            นักกีฬาอีสปอร์ตรุ่นถัดไป
          </span>
        </h2>
        
        <p className="text-slate-400 text-base md:text-lg mb-8 leading-relaxed max-w-xl mx-auto lg:mx-0">
          Astra Gaming สังกัดอีสปอร์ตระดับเวิลด์คลาส กำลังตามหาดาวเด่นดวงใหม่เข้าร่วมทัพสู้ศึกระดับสากล ไม่สำคัญว่าคุณจะเล่น Valorant, RoV หรือ PUBG ขอเพียงคุณมี "ปฏิกิริยาการตอบสนองที่เหนือมนุษย์" 
          สมัครเข้าร่วมและทำการทดสอบระบบประสาทผ่านระบบ AI/AR ล่าสุดเพื่อพิสูจน์ฝีมือคุณวันนี้!
        </p>

        {/* Stats Grid */}
        <div className="grid grid-cols-3 gap-6 max-w-md mx-auto lg:mx-0 bg-slate-900/40 p-5 rounded-xl border border-slate-800/80 mb-8">
          <div className="text-center">
            <div className="flex justify-center mb-1 text-slate-500">
              <Award className="w-5 h-5 text-indigo-400" />
            </div>
            <p className="text-2xl font-black text-white">12+</p>
            <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-wider">แชมป์ระดับประเทศ</p>
          </div>
          <div className="text-center border-x border-slate-800">
            <div className="flex justify-center mb-1 text-slate-500">
              <Star className="w-5 h-5 text-cyan-400" />
            </div>
            <p className="text-2xl font-black text-cyan-400">$2.5M+</p>
            <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-wider">เงินรางวัลสะสม</p>
          </div>
          <div className="text-center">
            <div className="flex justify-center mb-1 text-slate-500">
              <Users className="w-5 h-5 text-purple-400" />
            </div>
            <p className="text-2xl font-black text-indigo-400">30+</p>
            <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-wider">โปรเพลเยอร์ในทัพ</p>
          </div>
        </div>

        {/* Highlight Banner / Pro Tip */}
        <div className="hidden lg:block bg-gradient-to-r from-cyan-500/10 to-indigo-500/5 p-4 rounded-xl border border-cyan-500/20 max-w-xl">
          <p className="text-xs text-cyan-400 font-bold mb-1">🎮 ระบบการคัดเลือกรูปแบบใหม่:</p>
          <p className="text-xs text-slate-400 leading-relaxed">
            ผู้สมัครจำเป็นต้องล็อกอินและผ่านการทดสอบ <span className="font-bold text-slate-200">AR Hand-Tracking Reaction</span> บนเบราว์เซอร์ เพื่อวัดความรวดเร็วในการประสานงานระหว่างตาและมือ (Hand-Eye Coordination) สถิติคะแนนที่ดีที่สุดของคุณจะถูกจัดส่งและเก็บในระบบเพื่อพิจารณารับตัวเข้าสังกัด
          </p>
        </div>
      </div>

      {/* Right: Login Form */}
      <div className="lg:col-span-5 bg-slate-900 border border-slate-800 p-8 rounded-2xl shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -z-10"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-3xl -z-10"></div>

        <div className="mb-6">
          <h3 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
            <LogIn className="w-5 h-5 text-cyan-400" />
            เข้าสู่ระบบนักกีฬา
          </h3>
          <p className="text-xs text-slate-400">
            กรอกบัญชีผู้ใช้และรหัสผ่านเพื่อเข้าสู่ระบบทดสอบฝีมือ
          </p>
        </div>

        {/* Error message */}
        {error && (
          <div className="mb-5 bg-red-500/10 border border-red-500/30 text-red-400 text-xs p-3.5 rounded-lg flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-red-400 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              ชื่อผู้ใช้งาน (Username)
            </label>
            <input
              type="text"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="เช่น somchai_pro"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all"
            />
            <p className="text-[10px] text-slate-500 mt-1">
              * ข้อมูลตัวอย่างทดสอบ: <span className="font-bold text-slate-400">somchai</span> หรือ <span className="font-bold text-slate-400">jiraporn</span> รหัสผ่าน <span className="font-bold text-slate-400">password123</span>
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              รหัสผ่าน (Password)
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-sm py-3 px-4 rounded-lg shadow-lg shadow-cyan-500/10 hover:shadow-cyan-500/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                "เข้าสู่ระบบ"
              )}
            </button>
          </div>
        </form>

        <div className="mt-6 pt-6 border-t border-slate-800/80 text-center">
          <p className="text-xs text-slate-400 mb-3">
            ยังไม่ได้ลงทะเบียนเป็นสมาชิกสังกัดเราใช่หรือไม่?
          </p>
          <button
            onClick={onNavigateToRegister}
            className="w-full bg-slate-950 hover:bg-slate-800 text-cyan-400 border border-cyan-500/30 hover:border-cyan-400 font-bold text-xs py-2.5 px-4 rounded-lg transition-all flex items-center justify-center gap-2"
          >
            <UserPlus className="w-4 h-4" />
            ลงทะเบียนนักกีฬาใหม่
          </button>
        </div>
      </div>
    </div>
  );
}
