import { useState, FormEvent } from "react";
import { User } from "../types";
import { ShieldAlert, CheckCircle, Copy, Check, ArrowRight } from "lucide-react";

interface RegisterViewProps {
  onNavigateToLogin: () => void;
}

export default function RegisterView({ onNavigateToLogin }: RegisterViewProps) {
  // Input fields state
  const [fullname, setFullname] = useState("");
  const [ign, setIgn] = useState("");
  const [age, setAge] = useState("");
  const [game, setGame] = useState("Valorant");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [successUser, setSuccessUser] = useState<User | null>(null);
  const [copied, setCopied] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");

    const ageNum = parseInt(age);
    if (isNaN(ageNum) || ageNum < 12 || ageNum > 50) {
      setError("อายุของนักกีฬาต้องอยู่ระหว่าง 12 ถึง 50 ปี");
      return;
    }

    setLoading(true);

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullname,
          ign,
          age: ageNum,
          game,
          username,
          password,
        }),
      });
      const data = await res.json();

      if (res.ok && data.status === "success") {
        setSuccessUser(data.user);
      } else {
        setError(data.message || "เกิดข้อผิดพลาดในการลงทะเบียน กรุณาลองอีกครั้ง");
      }
    } catch (err) {
      setError("ไม่สามารถติดต่อเซิร์ฟเวอร์เพื่อส่งข้อมูลสมัครได้");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (successUser) {
      navigator.clipboard.writeText(successUser.athlete_id);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // If registered successfully, show the gorgeous digital athlete card!
  if (successUser) {
    return (
      <div className="w-full max-w-lg mx-auto bg-slate-900 border-2 border-cyan-500/30 p-8 rounded-2xl shadow-2xl shadow-cyan-500/10 text-center relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-gradient-to-tr from-cyan-500 to-indigo-500 rounded-full blur-3xl opacity-20"></div>
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-gradient-to-tr from-purple-500 to-pink-500 rounded-full blur-3xl opacity-10"></div>

        <div className="w-16 h-16 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center justify-center text-3xl mx-auto mb-6">
          <CheckCircle className="w-8 h-8 text-cyan-400" />
        </div>

        <h2 className="text-2xl font-black text-white mb-2">ลงทะเบียนผู้สมัครสำเร็จ!</h2>
        <p className="text-xs text-slate-400 mb-6">ระบบสุ่มสร้างและเปิดใช้งานรหัสประจำตัวนักกีฬาของคุณแล้ว</p>

        {/* Cyber Member Card */}
        <div className="bg-gradient-to-b from-slate-950 to-slate-900 border border-slate-800 rounded-xl p-6 text-left relative mb-8 overflow-hidden">
          <div className="absolute top-3 right-4 text-[9px] font-mono text-slate-600 tracking-widest uppercase">Astra Member Card</div>
          
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-500 flex items-center justify-center text-2xl font-black text-white shadow-md font-mono">
              AS
            </div>
            <div>
              <p className="text-xs text-slate-500">ชื่อนักกีฬา</p>
              <p className="text-lg font-bold text-white">{successUser.fullname}</p>
            </div>
          </div>

          <div className="mt-6 pt-5 border-t border-slate-800/60 grid grid-cols-2 gap-4">
            <div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">ATHLETE CODE</p>
              <p id="athlete-code" className="text-xl font-mono font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400 mt-1">
                {successUser.athlete_id}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">STATUS</p>
              <span className="inline-block bg-cyan-500/10 text-cyan-400 text-[10px] font-bold px-2.5 py-0.5 rounded border border-cyan-500/20 mt-1.5">
                ACTIVE MEMBER
              </span>
            </div>
          </div>
        </div>

        <div className="mb-6 bg-amber-500/5 border border-amber-500/10 py-3 px-4 rounded-lg text-left">
          <p className="text-xs text-amber-400 leading-relaxed">
            ⚠️ <span className="font-bold">คำแนะนำสิทธิ์:</span> กรุณาจดจำรหัสผ่าน และรหัสประจำตัวด้านบนเพื่อนำไปใช้เข้าสู่ระบบทดสอบปฏิกิริยาในหน้าล็อกอิน
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={handleCopy}
            className="flex-1 bg-slate-950 hover:bg-slate-800 text-slate-300 font-semibold text-xs py-3 px-4 rounded-lg border border-slate-800 hover:border-slate-700 transition-all flex items-center justify-center gap-2"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-400">คัดลอกเรียบร้อย!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-cyan-400" />
                <span>คัดลอกรหัสประจำตัว</span>
              </>
            )}
          </button>
          
          <button
            onClick={onNavigateToLogin}
            className="flex-1 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-xs py-3 px-4 rounded-lg transition-all flex items-center justify-center gap-1"
          >
            เข้าสู่หน้าล็อกอิน
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // Normal Form
  return (
    <div className="w-full max-w-2xl mx-auto bg-slate-900 border border-slate-800/80 p-8 rounded-2xl shadow-2xl relative">
      <div className="mb-8">
        <span className="text-xs text-cyan-400 font-semibold tracking-widest uppercase">Join Our Legacy</span>
        <h2 className="text-2xl font-black text-white mt-1">สมัครลงทะเบียนนักกีฬาใหม่</h2>
        <p className="text-xs text-slate-400 mt-1">สร้างโปรไฟล์ดิจิทัลของคุณและเตรียมพร้อมทดสอบประสาทสัมผัส</p>
      </div>

      {/* Error message */}
      {error && (
        <div className="mb-6 bg-red-500/10 border border-red-500/30 text-red-400 text-xs p-3.5 rounded-lg flex items-center gap-2">
          <ShieldAlert className="w-4 h-4 text-red-400 flex-shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Real Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              ชื่อจริง - นามสกุลจริง
            </label>
            <input
              type="text"
              required
              value={fullname}
              onChange={(e) => setFullname(e.target.value)}
              placeholder="เช่น นายสมเกียรติ พลากร"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all"
            />
          </div>

          {/* In-game Name (IGN) */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              ชื่อในเกม (In-game Name)
            </label>
            <input
              type="text"
              required
              value={ign}
              onChange={(e) => setIgn(e.target.value)}
              placeholder="เช่น SLAYER_zZ"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all"
            />
          </div>

          {/* Age */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              อายุ (ปี)
            </label>
            <input
              type="number"
              required
              min="12"
              max="50"
              value={age}
              onChange={(e) => setAge(e.target.value)}
              placeholder="เช่น 18"
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all"
            />
          </div>

          {/* Specialized Game */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1.5">
              เกมที่เชี่ยวชาญสูงสุด
            </label>
            <select
              value={game}
              onChange={(e) => setGame(e.target.value)}
              required
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 focus:outline-none focus:border-cyan-500 transition-all"
            >
              <option value="Valorant">Valorant</option>
              <option value="RoV">RoV (Arena of Valor)</option>
              <option value="PUBG">PUBG: BATTLEGROUNDS</option>
              <option value="FreeFire">Free Fire</option>
              <option value="Dota2">Dota 2</option>
            </select>
          </div>
        </div>

        {/* Credentials Part */}
        <div className="border-t border-slate-800/80 pt-6">
          <p className="text-xs font-bold text-cyan-400 mb-4 uppercase tracking-wider">
            ส่วนตั้งค่าบัญชีล็อกอิน
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Username */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                ชื่อบัญชีผู้ใช้ (Username)
              </label>
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="ภาษาอังกฤษ/ตัวเลขเท่านั้น"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all"
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                รหัสผ่าน (Password)
              </label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="ไม่ต่ำกว่า 6 ตัวอักษร"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-700 focus:outline-none focus:border-cyan-500 transition-all"
              />
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="pt-4 flex flex-col sm:flex-row items-center gap-4">
          <button
            type="submit"
            disabled={loading}
            className="w-full sm:w-auto flex-1 bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white font-bold text-sm py-3 px-8 rounded-lg shadow-lg shadow-cyan-500/15 transition-all flex items-center justify-center disabled:opacity-50"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              "ส่งใบสมัคร & สร้างรหัสผ่านนักกีฬา"
            )}
          </button>
          
          <button
            type="button"
            onClick={onNavigateToLogin}
            className="w-full sm:w-auto text-center bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 font-semibold text-xs py-3 px-6 rounded-lg transition-all"
          >
            ยกเลิก
          </button>
        </div>
      </form>
    </div>
  );
}
