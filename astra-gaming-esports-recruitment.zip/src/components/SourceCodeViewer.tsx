import { useState, useEffect } from "react";
import { Copy, Check, FileCode, Database, Terminal, Settings } from "lucide-react";

interface SourceFile {
  name: string;
  path: string;
  content: string;
}

export default function SourceCodeViewer() {
  const [files, setFiles] = useState<SourceFile[]>([]);
  const [activeTab, setActiveTab] = useState<string>("schema.sql");
  const [copied, setCopied] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    fetch("/api/php-source")
      .then((res) => res.json())
      .then((data) => {
        setFiles(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch PHP sources", err);
        setLoading(false);
      });
  }, []);

  const activeFile = files.find((f) => f.name === activeTab);

  const handleCopy = () => {
    if (activeFile) {
      navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 text-slate-400">
        <div className="w-6 h-6 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin mr-2"></div>
        กำลังโหลดไฟล์ต้นฉบับ PHP/MySQL...
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
      {/* Header */}
      <div className="p-6 border-b border-slate-800 bg-slate-950/40">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-lg border border-cyan-500/20">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-white text-lg flex items-center gap-2">
              โค้ด PHP & MySQL สำหรับรันบน XAMPP
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              คัดลอกไฟล์เหล่านี้เพื่อนำไปรันในเครื่องของคุณได้ทันที! รองรับ XAMPP (Localhost) เต็มรูปแบบ
            </p>
          </div>
        </div>

        {/* XAMPP Steps */}
        <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-3.5 text-xs">
          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800/60">
            <p className="font-bold text-cyan-400 mb-1">1. นำเข้าฐานข้อมูล</p>
            <p className="text-slate-400 leading-relaxed">
              เปิด <span className="text-slate-300 font-mono">phpMyAdmin</span> แล้วสร้างฐานข้อมูลใหม่ชื่อ <span className="font-bold text-white">astra_gaming</span> จากนั้นคัดลอกคำสั่งในแถบ <span className="text-indigo-400 font-mono font-semibold">schema.sql</span> ไปรันในแท็บ SQL
            </p>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800/60">
            <p className="font-bold text-cyan-400 mb-1">2. วางไฟล์ใน htdocs</p>
            <p className="text-slate-400 leading-relaxed">
              สร้างโฟลเดอร์ชื่อ <span className="text-slate-300 font-mono">astra-gaming</span> ในโฟลเดอร์ <span className="text-slate-300 font-mono">xampp/htdocs/</span> แล้วเซฟไฟล์ด้านล่างนี้ลงไปทั้งหมด (5 ไฟล์หลัก)
            </p>
          </div>
          <div className="bg-slate-950/60 p-3 rounded-lg border border-slate-800/60">
            <p className="font-bold text-cyan-400 mb-1">3. เปิดเว็บใช้งาน</p>
            <p className="text-slate-400 leading-relaxed">
              เปิดเบราว์เซอร์ไปที่ลิงก์ <a href="http://localhost/astra-gaming/" target="_blank" rel="noreferrer" className="text-cyan-400 font-bold hover:underline">http://localhost/astra-gaming/</a> เพื่อเริ่มใช้งานระบบสมัครนักกีฬาและเล่นเกม AR
            </p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap border-b border-slate-800 bg-slate-950/20 px-4 pt-2 gap-1 overflow-x-auto">
        {files.map((file) => {
          const isSql = file.name.endsWith(".sql");
          const isActive = activeTab === file.name;
          return (
            <button
              key={file.name}
              id={`tab-${file.name.replace(".", "-")}`}
              onClick={() => {
                setActiveTab(file.name);
                setCopied(false);
              }}
              className={`px-4 py-3 text-xs font-semibold rounded-t-lg flex items-center gap-2 border-t-2 transition-all ${
                isActive
                  ? "bg-slate-950 text-cyan-400 border-cyan-500 font-bold"
                  : "text-slate-400 border-transparent hover:text-slate-200 hover:bg-slate-800/40"
              }`}
            >
              {isSql ? (
                <Database className="w-3.5 h-3.5" />
              ) : (
                <FileCode className="w-3.5 h-3.5" />
              )}
              {file.name}
            </button>
          );
        })}
      </div>

      {/* Active Code Panel */}
      {activeFile && (
        <div className="relative bg-slate-950 p-6 flex flex-col">
          {/* Action Header */}
          <div className="flex justify-between items-center mb-4 text-xs">
            <span className="text-slate-500 flex items-center gap-1.5 font-mono">
              <Terminal className="w-3.5 h-3.5 text-slate-600" />
              path: {activeFile.path}
            </span>
            <button
              id="copy-btn"
              onClick={handleCopy}
              className="bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 font-semibold px-3 py-1.5 rounded-md flex items-center gap-1.5 transition-all"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400">คัดลอกแล้ว!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-cyan-400" />
                  <span>คัดลอกโค้ด</span>
                </>
              )}
            </button>
          </div>

          {/* Code display */}
          <div className="overflow-auto max-h-[480px] bg-slate-900/50 rounded-xl border border-slate-800 p-4 font-mono text-xs leading-relaxed text-slate-300">
            <pre className="whitespace-pre">{activeFile.content}</pre>
          </div>
        </div>
      )}
    </div>
  );
}
