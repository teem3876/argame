export interface User {
  id: number;
  athlete_id: string; // e.g. "AS-1234"
  fullname: string;
  ign: string; // In-Game Name
  age: number;
  game: string;
  username: string;
  high_score: number;
}

export interface Session {
  user: User | null;
}
